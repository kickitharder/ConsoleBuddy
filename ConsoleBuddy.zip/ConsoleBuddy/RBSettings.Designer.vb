﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class RBSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RBSettings))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnGetRB = New System.Windows.Forms.Button()
        Me.btnGetASCOM = New System.Windows.Forms.Button()
        Me.nudDEC = New System.Windows.Forms.NumericUpDown()
        Me.nudHA = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnAccUpdate = New System.Windows.Forms.Button()
        Me.btnUpdateAcc = New System.Windows.Forms.Button()
        Me.lblAccY = New System.Windows.Forms.Label()
        Me.lblAccX = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lblSettingsStatus = New System.Windows.Forms.Label()
        Me.grpSafety = New System.Windows.Forms.GroupBox()
        Me.chkTimerClose = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.nudMaxSpeed = New System.Windows.Forms.NumericUpDown()
        Me.chkRain = New System.Windows.Forms.CheckBox()
        Me.chkBattery = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.nudMoveTimer = New System.Windows.Forms.NumericUpDown()
        Me.chkAccel = New System.Windows.Forms.CheckBox()
        Me.chkIsParked = New System.Windows.Forms.CheckBox()
        Me.chkPark = New System.Windows.Forms.CheckBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnRetrieve = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.nudDEC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudHA, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.grpSafety.SuspendLayout()
        CType(Me.nudMaxSpeed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudMoveTimer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(6, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Hour Angle"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnGetRB)
        Me.GroupBox1.Controls.Add(Me.btnGetASCOM)
        Me.GroupBox1.Controls.Add(Me.nudDEC)
        Me.GroupBox1.Controls.Add(Me.nudHA)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(254, 102)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Home Position"
        '
        'btnGetRB
        '
        Me.btnGetRB.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnGetRB.Location = New System.Drawing.Point(156, 24)
        Me.btnGetRB.Name = "btnGetRB"
        Me.btnGetRB.Size = New System.Drawing.Size(88, 23)
        Me.btnGetRB.TabIndex = 5
        Me.btnGetRB.Text = "Get from RB"
        Me.btnGetRB.UseVisualStyleBackColor = True
        '
        'btnGetASCOM
        '
        Me.btnGetASCOM.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnGetASCOM.Location = New System.Drawing.Point(156, 53)
        Me.btnGetASCOM.Name = "btnGetASCOM"
        Me.btnGetASCOM.Size = New System.Drawing.Size(88, 23)
        Me.btnGetASCOM.TabIndex = 4
        Me.btnGetASCOM.Text = "Get ASCOM"
        Me.btnGetASCOM.UseVisualStyleBackColor = True
        '
        'nudDEC
        '
        Me.nudDEC.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudDEC.Location = New System.Drawing.Point(81, 54)
        Me.nudDEC.Maximum = New Decimal(New Integer() {90, 0, 0, 0})
        Me.nudDEC.Minimum = New Decimal(New Integer() {90, 0, 0, -2147483648})
        Me.nudDEC.Name = "nudDEC"
        Me.nudDEC.Size = New System.Drawing.Size(44, 23)
        Me.nudDEC.TabIndex = 3
        Me.nudDEC.Value = New Decimal(New Integer() {35, 0, 0, -2147483648})
        '
        'nudHA
        '
        Me.nudHA.DecimalPlaces = 1
        Me.nudHA.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudHA.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudHA.Location = New System.Drawing.Point(81, 24)
        Me.nudHA.Maximum = New Decimal(New Integer() {120, 0, 0, 65536})
        Me.nudHA.Minimum = New Decimal(New Integer() {119, 0, 0, -2147418112})
        Me.nudHA.Name = "nudHA"
        Me.nudHA.Size = New System.Drawing.Size(44, 23)
        Me.nudHA.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(6, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Declination"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnAccUpdate)
        Me.GroupBox2.Controls.Add(Me.btnUpdateAcc)
        Me.GroupBox2.Controls.Add(Me.lblAccY)
        Me.GroupBox2.Controls.Add(Me.lblAccX)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.GroupBox2.Location = New System.Drawing.Point(7, 118)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(254, 91)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Accelerometer"
        '
        'btnAccUpdate
        '
        Me.btnAccUpdate.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnAccUpdate.Location = New System.Drawing.Point(156, 23)
        Me.btnAccUpdate.Name = "btnAccUpdate"
        Me.btnAccUpdate.Size = New System.Drawing.Size(88, 23)
        Me.btnAccUpdate.TabIndex = 8
        Me.btnAccUpdate.Text = "Get State"
        Me.btnAccUpdate.UseVisualStyleBackColor = True
        '
        'btnUpdateAcc
        '
        Me.btnUpdateAcc.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnUpdateAcc.Location = New System.Drawing.Point(156, 52)
        Me.btnUpdateAcc.Name = "btnUpdateAcc"
        Me.btnUpdateAcc.Size = New System.Drawing.Size(88, 23)
        Me.btnUpdateAcc.TabIndex = 7
        Me.btnUpdateAcc.Text = "Use for Park"
        Me.btnUpdateAcc.UseVisualStyleBackColor = True
        '
        'lblAccY
        '
        Me.lblAccY.AutoSize = True
        Me.lblAccY.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblAccY.Location = New System.Drawing.Point(90, 53)
        Me.lblAccY.Name = "lblAccY"
        Me.lblAccY.Size = New System.Drawing.Size(13, 15)
        Me.lblAccY.TabIndex = 6
        Me.lblAccY.Text = "0"
        '
        'lblAccX
        '
        Me.lblAccX.AutoSize = True
        Me.lblAccX.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblAccX.Location = New System.Drawing.Point(90, 31)
        Me.lblAccX.Name = "lblAccX"
        Me.lblAccX.Size = New System.Drawing.Size(13, 15)
        Me.lblAccX.TabIndex = 4
        Me.lblAccX.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(12, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 15)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Roll (RA)"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(12, 31)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 15)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Pitch (Dec)"
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(318, 231)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(60, 23)
        Me.btnOK.TabIndex = 3
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = True
        Me.lblVersion.Location = New System.Drawing.Point(11, 239)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(45, 15)
        Me.lblVersion.TabIndex = 5
        Me.lblVersion.Text = "Version"
        '
        'lblSettingsStatus
        '
        Me.lblSettingsStatus.AutoSize = True
        Me.lblSettingsStatus.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.lblSettingsStatus.Location = New System.Drawing.Point(13, 214)
        Me.lblSettingsStatus.Name = "lblSettingsStatus"
        Me.lblSettingsStatus.Size = New System.Drawing.Size(170, 15)
        Me.lblSettingsStatus.TabIndex = 8
        Me.lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        '
        'grpSafety
        '
        Me.grpSafety.Controls.Add(Me.chkTimerClose)
        Me.grpSafety.Controls.Add(Me.Label8)
        Me.grpSafety.Controls.Add(Me.nudMaxSpeed)
        Me.grpSafety.Controls.Add(Me.chkRain)
        Me.grpSafety.Controls.Add(Me.chkBattery)
        Me.grpSafety.Controls.Add(Me.Label6)
        Me.grpSafety.Controls.Add(Me.Label5)
        Me.grpSafety.Controls.Add(Me.nudMoveTimer)
        Me.grpSafety.Controls.Add(Me.chkAccel)
        Me.grpSafety.Controls.Add(Me.chkIsParked)
        Me.grpSafety.Controls.Add(Me.chkPark)
        Me.grpSafety.Cursor = System.Windows.Forms.Cursors.Default
        Me.grpSafety.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpSafety.Location = New System.Drawing.Point(271, 8)
        Me.grpSafety.Name = "grpSafety"
        Me.grpSafety.Size = New System.Drawing.Size(181, 217)
        Me.grpSafety.TabIndex = 9
        Me.grpSafety.TabStop = False
        Me.grpSafety.Text = "Safety"
        '
        'chkTimerClose
        '
        Me.chkTimerClose.AutoSize = True
        Me.chkTimerClose.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.chkTimerClose.Location = New System.Drawing.Point(5, 134)
        Me.chkTimerClose.Name = "chkTimerClose"
        Me.chkTimerClose.Size = New System.Drawing.Size(165, 19)
        Me.chkTimerClose.TabIndex = 16
        Me.chkTimerClose.Text = "Close when Timer finished"
        Me.chkTimerClose.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(3, 192)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(93, 15)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Max Roof Speed"
        '
        'nudMaxSpeed
        '
        Me.nudMaxSpeed.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudMaxSpeed.Location = New System.Drawing.Point(98, 190)
        Me.nudMaxSpeed.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.nudMaxSpeed.Name = "nudMaxSpeed"
        Me.nudMaxSpeed.Size = New System.Drawing.Size(44, 23)
        Me.nudMaxSpeed.TabIndex = 14
        Me.nudMaxSpeed.Value = New Decimal(New Integer() {255, 0, 0, 0})
        '
        'chkRain
        '
        Me.chkRain.AutoSize = True
        Me.chkRain.Checked = True
        Me.chkRain.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkRain.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.chkRain.Location = New System.Drawing.Point(6, 111)
        Me.chkRain.Name = "chkRain"
        Me.chkRain.Size = New System.Drawing.Size(86, 19)
        Me.chkRain.TabIndex = 10
        Me.chkRain.Text = "Detect Rain"
        Me.chkRain.UseVisualStyleBackColor = True
        '
        'chkBattery
        '
        Me.chkBattery.AutoSize = True
        Me.chkBattery.Checked = True
        Me.chkBattery.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkBattery.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.chkBattery.Location = New System.Drawing.Point(6, 88)
        Me.chkBattery.Name = "chkBattery"
        Me.chkBattery.Size = New System.Drawing.Size(92, 19)
        Me.chkBattery.TabIndex = 9
        Me.chkBattery.Text = "Battery State"
        Me.chkBattery.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(142, 163)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 15)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "secs"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(3, 163)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 15)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Move Timer"
        '
        'nudMoveTimer
        '
        Me.nudMoveTimer.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudMoveTimer.Location = New System.Drawing.Point(98, 161)
        Me.nudMoveTimer.Maximum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.nudMoveTimer.Name = "nudMoveTimer"
        Me.nudMoveTimer.Size = New System.Drawing.Size(44, 23)
        Me.nudMoveTimer.TabIndex = 3
        Me.nudMoveTimer.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'chkAccel
        '
        Me.chkAccel.AutoSize = True
        Me.chkAccel.Checked = True
        Me.chkAccel.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkAccel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.chkAccel.Location = New System.Drawing.Point(6, 66)
        Me.chkAccel.Name = "chkAccel"
        Me.chkAccel.Size = New System.Drawing.Size(103, 19)
        Me.chkAccel.TabIndex = 2
        Me.chkAccel.Text = "Accelerometer"
        Me.chkAccel.UseVisualStyleBackColor = True
        '
        'chkIsParked
        '
        Me.chkIsParked.AutoSize = True
        Me.chkIsParked.Checked = True
        Me.chkIsParked.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkIsParked.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.chkIsParked.Location = New System.Drawing.Point(6, 44)
        Me.chkIsParked.Name = "chkIsParked"
        Me.chkIsParked.Size = New System.Drawing.Size(73, 19)
        Me.chkIsParked.TabIndex = 1
        Me.chkIsParked.Text = "Is Parked"
        Me.chkIsParked.UseVisualStyleBackColor = True
        '
        'chkPark
        '
        Me.chkPark.AutoSize = True
        Me.chkPark.Checked = True
        Me.chkPark.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPark.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.chkPark.Location = New System.Drawing.Point(6, 22)
        Me.chkPark.Name = "chkPark"
        Me.chkPark.Size = New System.Drawing.Size(84, 19)
        Me.chkPark.TabIndex = 0
        Me.chkPark.Text = "Park Scope"
        Me.chkPark.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(384, 231)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(60, 23)
        Me.btnCancel.TabIndex = 11
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnRetrieve
        '
        Me.btnRetrieve.Location = New System.Drawing.Point(228, 231)
        Me.btnRetrieve.Name = "btnRetrieve"
        Me.btnRetrieve.Size = New System.Drawing.Size(84, 23)
        Me.btnRetrieve.TabIndex = 12
        Me.btnRetrieve.Text = "Retrieve Data"
        Me.btnRetrieve.UseVisualStyleBackColor = True
        '
        'RBSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(463, 262)
        Me.Controls.Add(Me.btnRetrieve)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.grpSafety)
        Me.Controls.Add(Me.lblSettingsStatus)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "RBSettings"
        Me.ShowIcon = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = " RoofBuddy Settings"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.nudDEC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudHA, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.grpSafety.ResumeLayout(False)
        Me.grpSafety.PerformLayout()
        CType(Me.nudMaxSpeed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudMoveTimer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnGetRB As Button
    Friend WithEvents btnGetASCOM As Button
    Friend WithEvents nudDEC As NumericUpDown
    Friend WithEvents nudHA As NumericUpDown
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnUpdateAcc As Button
    Friend WithEvents lblAccY As Label
    Friend WithEvents lblAccX As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnOK As Button
    Friend WithEvents lblVersion As Label
    Friend WithEvents btnAccUpdate As Button
    Friend WithEvents lblSettingsStatus As Label
    Friend WithEvents grpSafety As GroupBox
    Friend WithEvents chkAccel As CheckBox
    Friend WithEvents chkIsParked As CheckBox
    Friend WithEvents chkPark As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents nudMoveTimer As NumericUpDown
    Friend WithEvents chkBattery As CheckBox
    Friend WithEvents btnCancel As Button
    Friend WithEvents chkRain As CheckBox
    Friend WithEvents btnRetrieve As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents nudMaxSpeed As NumericUpDown
    Friend WithEvents chkTimerClose As CheckBox
End Class
