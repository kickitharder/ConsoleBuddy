﻿Imports System.IO.Ports
Imports System.IO
Public Class RBSettings
    Dim comError As Boolean = False
    Dim respStr As String = ""
    Dim updateRB As Boolean
    Dim gotData As Boolean = False
    Private Sub Settings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Visible = True
        If Not gotData Then
            lblSettingsStatus.Text = "Getting data from RoofBuddy..."
            Application.DoEvents()
            RetrieveSettings()
        End If
        Application.DoEvents()
        updateRB = False
        gotData = True
    End Sub

    Private Function SerialCommand(cmdStr As String) As Boolean
        If cmdStr = "" Then Return ""
        comError = False
        Dim objSerial As New SerialPort
        If cmdStr.StartsWith("@") Then
            cmdStr += vbLf
        Else
            cmdStr = "^" + Asc(cmdStr.Substring(0, 1)).ToString + IIf(cmdStr.Length > 1, cmdStr.Substring(1), "") + "$"
        End If
        Try
            With objSerial
                .PortName = Form1.comPort
                .BaudRate = 9600
                .ReadTimeout = 5000
                .WriteTimeout = 1000
                .Open()
                .Write(cmdStr)
            End With
            If cmdStr.StartsWith("@") Then
                respStr = objSerial.ReadTo(vbCrLf)
            Else
                respStr = objSerial.ReadTo("$")
            End If
        Catch ex As Exception
            comError = True
            lblSettingsStatus.Text = "RoofBuddy not responding (" + cmdStr + ")"
        End Try

        objSerial.Close()
        objSerial.Dispose()
        Return comError
    End Function

    Private Sub nudHA_ValueChanged(sender As Object, e As EventArgs) Handles nudHA.ValueChanged
        lblSettingsStatus.Text = ""
        updateRB = True
    End Sub

    Private Sub nudDEC_ValueChanged(sender As Object, e As EventArgs) Handles nudDEC.ValueChanged
        lblSettingsStatus.Text = ""
        updateRB = True
    End Sub

    Private Sub btnGetRB_Click(sender As Object, e As EventArgs) Handles btnGetRB.Click
        lblSettingsStatus.Text = "Getting RoofBuddy home settings..."
        Application.DoEvents()
        If SerialCommand("a") Then Exit Sub
        If respStr <> "" AndAlso CDec(respStr) <= nudHA.Maximum AndAlso CDec(respStr) >= nudHA.Minimum Then nudHA.Value = CDec(respStr)
        If SerialCommand("d") Then Exit Sub
        If respStr <> "" AndAlso CDec(respStr) <= nudDEC.Maximum AndAlso CDec(respStr) >= nudDEC.Minimum Then nudDEC.Value = CDec(respStr)
        lblSettingsStatus.Text = "Got RoofBuddy home settings"
    End Sub

    Private Sub btnGetASCOM_Click(sender As Object, e As EventArgs) Handles btnGetASCOM.Click
        lblSettingsStatus.Text = ""
        Application.DoEvents()
        Dim line As String
        Dim valStr As String
        Dim settingsFile = My.Computer.FileSystem.SpecialDirectories.MyDocuments + "\ASCOM\MeadeLX200Classic\settings.ini"

        If File.Exists(settingsFile) = False Then
            lblSettingsStatus.Text = "ASCOM file not found"
            Exit Sub
        End If

        FileOpen(1, settingsFile, OpenMode.Input)
        While EOF(1) = False
            line = LineInput(1)
            valStr = Trim(Mid(line, InStr(line, "=") + 1, 256))
            Select Case Trim(Strings.Left(line, InStr(line, "=") - 1))
                Case "Home Position Hour Angle"
                    nudHA.Value = CDec(valStr)
                Case "Home Position Declination"
                    nudDEC.Value = CDec(valStr)
            End Select
        End While
        FileClose(1)
        lblSettingsStatus.Text = "Got ASCOM settings"
    End Sub

    Private Sub btnAccUpdate_Click(sender As Object, e As EventArgs) Handles btnAccUpdate.Click
        lblSettingsStatus.Text = ""
        Application.DoEvents()
        If SerialCommand("@X") Then Exit Sub
        lblAccX.Text = respStr
        If SerialCommand("@Y") Then Exit Sub
        lblAccY.Text = respStr
        lblSettingsStatus.Text = "Got Accelerometer values"
    End Sub

    Private Sub btnUpdateAcc_Click(sender As Object, e As EventArgs) Handles btnUpdateAcc.Click
        lblSettingsStatus.Text = "Updating Accelerometer offsets"
        Application.DoEvents()
        If SerialCommand("@I") Then Exit Sub        ' Calculate offsets
        If SerialCommand("@S") Then Exit Sub        ' Save offsets
        If SerialCommand("@X") Then Exit Sub
        lblAccX.Text = respStr
        If SerialCommand("@Y") Then Exit Sub
        lblAccY.Text = respStr
        lblSettingsStatus.Text = "Accelerometer offsets updated"
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        If updateRB Then
            lblSettingsStatus.Text = "Updating RoofBuddy..."
            Application.DoEvents()
            If SerialCommand("D=" + nudDEC.Value.ToString) Then Exit Sub
            If SerialCommand("S=" + nudHA.Value.ToString) Then Exit Sub
            If SerialCommand("U" + IIf(chkPark.Checked, "P", "p")) Then Exit Sub
            If SerialCommand("U" + IIf(chkIsParked.Checked, "I", "i")) Then Exit Sub
            If SerialCommand("U" + IIf(chkAccel.Checked, "S", "s")) Then Exit Sub
            If SerialCommand("U" + IIf(chkBattery.Checked, "B", "b")) Then Exit Sub
            If SerialCommand("U" + IIf(chkRain.Checked, "R", "r")) Then Exit Sub
            If SerialCommand("M=" + nudMoveTimer.Value.ToString) Then Exit Sub
            If SerialCommand("X=" + nudMaxSpeed.Value.ToString) Then Exit Sub
            lblSettingsStatus.Text = ""
        End If
        Close()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Close()
    End Sub

    Private Sub chkPark_CheckedChanged(sender As Object, e As EventArgs) Handles chkPark.CheckedChanged
        updateRB = True
    End Sub

    Private Sub chkParked_CheckedChanged(sender As Object, e As EventArgs) Handles chkIsParked.CheckedChanged
        updateRB = True
    End Sub

    Private Sub chkAccel_CheckedChanged(sender As Object, e As EventArgs) Handles chkAccel.CheckedChanged
        updateRB = True
    End Sub

    Private Sub chkBattery_CheckedChanged(sender As Object, e As EventArgs) Handles chkBattery.CheckedChanged
        updateRB = True
    End Sub

    Private Sub chkRain_CheckedChanged(sender As Object, e As EventArgs) Handles chkRain.CheckedChanged
        updateRB = True
    End Sub

    Private Sub nudMoveTimer_ValueChanged(sender As Object, e As EventArgs) Handles nudMoveTimer.ValueChanged
        updateRB = True
    End Sub

    Private Sub nudMaxSpeed_ValueChanged(sender As Object, e As EventArgs)
        updateRB = True
    End Sub

    Private Sub nudPollRate_ValueChanged(sender As Object, e As EventArgs)
        updateRB = True
    End Sub

    Private Sub btnRetrieve_Click(sender As Object, e As EventArgs) Handles btnRetrieve.Click
        RetrieveSettings()
    End Sub

    Private Sub RetrieveSettings()
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        Application.DoEvents()
        If SerialCommand("a") Then Exit Sub
        If respStr <> "" AndAlso CDec(respStr <= nudHA.Maximum) AndAlso CDec(respStr >= nudHA.Minimum) Then nudHA.Value = CDec(respStr)
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        If SerialCommand("d") Then Exit Sub
        If respStr <> "" AndAlso CDec(respStr <= nudDEC.Maximum) AndAlso CDec(respStr >= nudDEC.Minimum) Then nudDEC.Value = CDec(respStr)
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        If SerialCommand("@X") Then Exit Sub
        lblAccX.Text = respStr
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        If SerialCommand("@Y") Then Exit Sub
        lblAccY.Text = respStr
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        If SerialCommand("uP") Then Exit Sub
        chkPark.Checked = IIf(respStr = "0", False, True)
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        If SerialCommand("uI") Then Exit Sub
        chkIsParked.Checked = IIf(respStr = "0", False, True)
        If SerialCommand("uS") Then Exit Sub
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        chkAccel.Checked = IIf(respStr = "0", False, True)
        If SerialCommand("uB") Then Exit Sub
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        chkBattery.Checked = IIf(respStr = "0", False, True)
        If SerialCommand("uR") Then Exit Sub
        chkRain.Checked = IIf(respStr = "0", False, True)
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        chkTimerClose.Checked = Form1.timerCloseRoof
        If SerialCommand("m") Then Exit Sub
        nudMoveTimer.Value = CDec(respStr)
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        If SerialCommand("x") Then Exit Sub
        nudMaxSpeed.Value = CDec(respStr)
        lblSettingsStatus.Text = "Getting data from RoofBuddy..."
        If SerialCommand("V") Then Exit Sub
        lblVersion.Text = respStr.Substring(0, 19)
        lblSettingsStatus.Text = "Ready"
    End Sub
End Class