﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Location = Form1.Location
        Me.cbxMoves.Items.Clear()
        For i = 0 To Form1.cbxMoves.Items.Count - 1
            Me.cbxMoves.Items.Add(Form1.cbxMoves.Items(i))
        Next
        Me.cbxMoves.SelectedItem = Form1.cbxMoves.SelectedItem
        infoUpdate(IIf(Form1.notMoving, "FocusBuddy", "Moving..."), Form1.txtCurrPos.Text, Form1.txtLastMove.Text)
    End Sub

    Private Sub Form2_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Form1.Visible = True
        Me.Close()
    End Sub

    Private Sub cbxMoves_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxMoves.SelectedIndexChanged
        Form1.cbxMoves.SelectedItem = Me.cbxMoves.SelectedItem
    End Sub

    Public Sub infoUpdate(nameText As String, currPos As String, lastMove As String)
        currPos = Format(CInt(currPos), "#,##0")
        Me.Text = nameText
        Me.txtCurrPos.Text = currPos
        Me.txtLastMove.Text = lastMove
    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        Form1.StopFocuser()
    End Sub

    Private Sub btnMoveIn_Click(sender As Object, e As EventArgs) Handles btnMoveIn.Click
        Dim dist As String = cbxMoves.SelectedItem.ToString
        If dist.Contains("Custom") Then dist = Form1.nudMove.Value.ToString
        Form1.DoMove("I", "I" + dist)
    End Sub

    Private Sub btnMoveOut_Click(sender As Object, e As EventArgs) Handles btnMoveOut.Click
        Dim dist As String = cbxMoves.SelectedItem.ToString
        If dist.Contains("Custom") Then dist = Form1.nudMove.Value.ToString
        Form1.DoMove("O", "O" + dist)
    End Sub
    Private Sub btnMoveFullyIn_Click(sender As Object, e As EventArgs) Handles btnMoveFullyIn.Click
        Form1.DoMove("I", "I")
    End Sub

    Private Sub btnMoveFullyOut_Click(sender As Object, e As EventArgs) Handles btnMoveFullyOut.Click
        Form1.DoMove("O", "O")
    End Sub

    Private Sub btnPulseIn_MouseDown(sender As Object, e As MouseEventArgs) Handles btnPulseIn.MouseDown
        Form1.DoMove("I", "I")
    End Sub

    Private Sub btnPulseIn_MouseUp(sender As Object, e As MouseEventArgs) Handles btnPulseIn.MouseUp
        Form1.StopFocuser()
    End Sub

    Private Sub btnPulseOut_MouseDown(sender As Object, e As MouseEventArgs) Handles btnPulseOut.MouseDown
        Form1.DoMove("O", "O")
    End Sub

    Private Sub btnPulseOut_MouseUp(sender As Object, e As MouseEventArgs) Handles btnPulseOut.MouseUp
        Form1.StopFocuser()
    End Sub
End Class