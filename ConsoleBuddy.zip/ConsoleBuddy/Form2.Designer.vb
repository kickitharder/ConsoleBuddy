﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.btnMoveFullyIn = New System.Windows.Forms.Button()
        Me.btnMoveIn = New System.Windows.Forms.Button()
        Me.btnPulseIn = New System.Windows.Forms.Button()
        Me.btnPulseOut = New System.Windows.Forms.Button()
        Me.btnMoveOut = New System.Windows.Forms.Button()
        Me.btnMoveFullyOut = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.cbxMoves = New System.Windows.Forms.ComboBox()
        Me.txtCurrPos = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtLastMove = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnMoveFullyIn
        '
        Me.btnMoveFullyIn.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnMoveFullyIn.Location = New System.Drawing.Point(5, 5)
        Me.btnMoveFullyIn.Name = "btnMoveFullyIn"
        Me.btnMoveFullyIn.Size = New System.Drawing.Size(36, 22)
        Me.btnMoveFullyIn.TabIndex = 0
        Me.btnMoveFullyIn.Text = "|<<"
        Me.btnMoveFullyIn.UseVisualStyleBackColor = True
        '
        'btnMoveIn
        '
        Me.btnMoveIn.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnMoveIn.Location = New System.Drawing.Point(39, 5)
        Me.btnMoveIn.Name = "btnMoveIn"
        Me.btnMoveIn.Size = New System.Drawing.Size(36, 22)
        Me.btnMoveIn.TabIndex = 1
        Me.btnMoveIn.Text = "<<"
        Me.btnMoveIn.UseVisualStyleBackColor = True
        '
        'btnPulseIn
        '
        Me.btnPulseIn.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnPulseIn.Location = New System.Drawing.Point(73, 5)
        Me.btnPulseIn.Name = "btnPulseIn"
        Me.btnPulseIn.Size = New System.Drawing.Size(36, 22)
        Me.btnPulseIn.TabIndex = 2
        Me.btnPulseIn.Text = "<"
        Me.btnPulseIn.UseVisualStyleBackColor = True
        '
        'btnPulseOut
        '
        Me.btnPulseOut.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnPulseOut.Location = New System.Drawing.Point(107, 5)
        Me.btnPulseOut.Name = "btnPulseOut"
        Me.btnPulseOut.Size = New System.Drawing.Size(36, 22)
        Me.btnPulseOut.TabIndex = 3
        Me.btnPulseOut.Text = ">"
        Me.btnPulseOut.UseVisualStyleBackColor = True
        '
        'btnMoveOut
        '
        Me.btnMoveOut.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnMoveOut.Location = New System.Drawing.Point(141, 5)
        Me.btnMoveOut.Name = "btnMoveOut"
        Me.btnMoveOut.Size = New System.Drawing.Size(36, 22)
        Me.btnMoveOut.TabIndex = 4
        Me.btnMoveOut.Text = ">>"
        Me.btnMoveOut.UseVisualStyleBackColor = True
        '
        'btnMoveFullyOut
        '
        Me.btnMoveFullyOut.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnMoveFullyOut.Location = New System.Drawing.Point(175, 5)
        Me.btnMoveFullyOut.Name = "btnMoveFullyOut"
        Me.btnMoveFullyOut.Size = New System.Drawing.Size(36, 22)
        Me.btnMoveFullyOut.TabIndex = 5
        Me.btnMoveFullyOut.Text = ">>|"
        Me.btnMoveFullyOut.UseVisualStyleBackColor = True
        '
        'btnStop
        '
        Me.btnStop.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnStop.Location = New System.Drawing.Point(5, 33)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(46, 48)
        Me.btnStop.TabIndex = 6
        Me.btnStop.Text = "STOP"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'cbxMoves
        '
        Me.cbxMoves.FormattingEnabled = True
        Me.cbxMoves.Location = New System.Drawing.Point(107, 33)
        Me.cbxMoves.Name = "cbxMoves"
        Me.cbxMoves.Size = New System.Drawing.Size(104, 23)
        Me.cbxMoves.TabIndex = 7
        '
        'txtCurrPos
        '
        Me.txtCurrPos.Location = New System.Drawing.Point(107, 62)
        Me.txtCurrPos.Name = "txtCurrPos"
        Me.txtCurrPos.Size = New System.Drawing.Size(57, 23)
        Me.txtCurrPos.TabIndex = 9
        Me.txtCurrPos.Text = "-------"
        Me.txtCurrPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(54, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 15)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "<<  >>"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(52, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 15)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Position"
        '
        'txtLastMove
        '
        Me.txtLastMove.Location = New System.Drawing.Point(170, 62)
        Me.txtLastMove.Name = "txtLastMove"
        Me.txtLastMove.Size = New System.Drawing.Size(40, 23)
        Me.txtLastMove.TabIndex = 12
        Me.txtLastMove.Text = "---"
        Me.txtLastMove.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(219, 94)
        Me.Controls.Add(Me.txtLastMove)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtCurrPos)
        Me.Controls.Add(Me.cbxMoves)
        Me.Controls.Add(Me.btnStop)
        Me.Controls.Add(Me.btnMoveFullyOut)
        Me.Controls.Add(Me.btnMoveOut)
        Me.Controls.Add(Me.btnPulseOut)
        Me.Controls.Add(Me.btnPulseIn)
        Me.Controls.Add(Me.btnMoveIn)
        Me.Controls.Add(Me.btnMoveFullyIn)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form2"
        Me.ShowIcon = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "FocusBuddy"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnMoveFullyIn As Button
    Friend WithEvents btnMoveIn As Button
    Friend WithEvents btnPulseIn As Button
    Friend WithEvents btnPulseOut As Button
    Friend WithEvents btnMoveOut As Button
    Friend WithEvents btnMoveFullyOut As Button
    Friend WithEvents btnStop As Button
    Friend WithEvents cbxMoves As ComboBox
    Friend WithEvents txtCurrPos As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtLastMove As TextBox
End Class
