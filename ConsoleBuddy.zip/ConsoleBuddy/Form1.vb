Imports System.Runtime.InteropServices
Imports System.IO
Imports System.IO.Ports

<ComVisible(False)>
Public Class Form1
    Const version As String = "Version 2.220501"
    Dim settingsPath As String = ""
    Dim settingsFile As String = "settings.ini"
    Dim commsError As Boolean = False
    Dim commsErrorMsg As Boolean = True
    Dim respStr As String = ""
    ReadOnly resp(20) As String
    Dim updateArduino As Boolean = False
    Friend comPort As String = ""
    ReadOnly getSettingsFlag As Boolean
    Dim canUpdate As Boolean = False
    Public notMoving As Boolean = True
    Dim comPortOk As Boolean = True
    Friend RBpollRate As Integer = 0
    Friend RBSpeak As Boolean
    Dim timerFlag As Boolean = False
    Friend timerCloseRoof As Boolean = False

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Me.Width = 650
        settingsPath = My.Computer.FileSystem.SpecialDirectories.MyDocuments + "\FocusBuddy"
        settingsFile = settingsPath + "\" + settingsFile
        lblVersion.Text = version
        updateArduino = False
        GetSettings()
        btnUpdate.Enabled = False
        btnSync.Enabled = False
        btnReFormat.Enabled = True
        ComboBoxComPort.Items.Clear()
        ComboBoxComPort.Items.AddRange(SerialPort.GetPortNames())
        Dim listLength As Integer = ComboBoxComPort.Items.Count - 1
        Dim list(listLength) As Integer
        For i = 0 To listLength
            list(i) = Str(Mid(ComboBoxComPort.Items(i), 4, 3))
        Next
        Array.Sort(list)
        ComboBoxComPort.Items.Clear()
        For i = 0 To listLength
            ComboBoxComPort.Items.Add("COM" + list(i).ToString)
        Next
        If ComboBoxComPort.Items.Contains(comPort) Then
            ComboBoxComPort.SelectedItem = comPort
        End If
        If ComboBoxComPort.SelectedIndex > 0 Then lblStatus.Text = "Ready to attempt connection..."
        comPortOk = True
        If chkConnectOnStartUp.Checked Then Retrieve()
        cbxMoves.Items.Clear()
        cbxMoves.Items.Add(nudMove.Value.ToString + " (Custom)")
        cbxMoves.Items.Add("100")
        cbxMoves.Items.Add("200")
        cbxMoves.Items.Add("500")
        cbxMoves.Items.Add("1000")
        cbxMoves.Items.Add("2000")
        cbxMoves.Items.Add("5000")
        cbxMoves.SelectedIndex = 0
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Timer1.Stop()
        Timer2.Stop()
        Arduino(respStr, "Q")
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs)
        'If MsgBox("Are you sure you want to leave?", vbYesNo, "FocusBuddy") = vbNo Then Exit Sub
        Timer1.Stop()
        Timer2.Stop()
        Arduino(respStr, "Q")
        Close()
    End Sub

    Private Sub Retrieve()
        btnMiniFocuser.Enabled = False
        If ComboBoxComPort.SelectedIndex = -1 Then
            MsgBox("Please select COM port for FocusBuddy controller",, "FocusBuddy")
            Exit Sub
        End If

        lblRetrieve.Visible = True
        Dim i As Integer
        commsError = False
        commsErrorMsg = True
        If Arduino(respStr, "Q") Then Exit Sub
        'Arduino(respStr, "R")                                           ' Reset Adruino and it's clock
        lblStatus.Text = ""
        For i = 1 To 10
            If i = 10 Then Exit Sub
            System.Threading.Thread.Sleep(100)
            commsError = False
            If Not Arduino(respStr, "V") Then Exit For
            commsErrorMsg = False
        Next

        commsErrorMsg = True
        If respStr.Contains("FocusBuddy") And commsError = False Then
            respStr = Mid(respStr, InStr(respStr, "FocusBuddy"), 64)
            lblStatus.Text = respStr + ".  FocusBuddy is responding."
            btnMiniFocuser.Enabled = True
        Else
            commsError = True
            lblRetrieve.Visible = False
            lblStatus.Text = "Ready to attempt connection..."
            Exit Sub
        End If

        For i = 0 To 9
            If Arduino(resp(i), "E" + i.ToString) Then Exit Sub
            If Arduino(resp(i + 10), "N" + i.ToString) Then Exit Sub
        Next
        If Arduino(resp(20), "P") Then Exit Sub
        lblRetrieve.Visible = False

        If commsError Then Return
        btnUpdate.Enabled = False
        nudPreset9.Value = CDec(resp(9))
        nudPreset0.Value = CDec(resp(0))
        nudPreset1.Value = CDec(resp(1))
        nudPreset2.Value = CDec(resp(2))
        nudPreset3.Value = CDec(resp(3))
        nudPreset4.Value = CDec(resp(4))
        nudPreset5.Value = CDec(resp(5))
        nudPreset6.Value = CDec(resp(6))
        nudPreset7.Value = CDec(resp(7))
        nudPreset8.Value = CDec(resp(8))
        txtName0.Text = resp(10)
        txtName1.Text = resp(11)
        txtName2.Text = resp(12)
        txtName3.Text = resp(13)
        txtName4.Text = resp(14)
        txtName5.Text = resp(15)
        txtName6.Text = resp(16)
        txtName7.Text = resp(17)
        txtName8.Text = resp(18)
        txtName9.Text = resp(19)
        If resp(20) < 1 Then resp(20) = 1
        If resp(20) > nudPreset9.Maximum Then resp(20) = nudPreset9.Maximum
        If Arduino(respStr, "p" + resp(20).ToString) Then Exit Sub
        updateButtons()
        TimerUpdate()
        If Arduino(respStr, "Q") Then Exit Sub
        If Arduino(respStr, "r") Then Exit Sub
        respStr = ("0000000" + Hex(respStr))
        respStr = respStr.Substring(respStr.Length - 8)
        lblMillis.Text = respStr
        txtCurrPos.Text = Format(CInt(Val(resp(20))), "#,##0")
        nudTarget.Value = CDec(resp(20))
        radTarget.Checked = True
        Timer1.Interval = 1000
        btnUpdate.Enabled = False
        btnTimer.Enabled = True
        RBstatus()
        ServiceTimer()
    End Sub

    Private Function Arduino(ByRef resp As String, cmdStr As String) As Boolean
        resp = ""
        If commsError Then Return commsError

        Dim objSerial As New System.IO.Ports.SerialPort
        If ComboBoxComPort.SelectedIndex = -1 Then
            commsError = True
            Return commsError
        End If
        'Dim comPort = ComboBoxComPort.SelectedItem.ToString
        Try
            With objSerial
                .PortName = ComboBoxComPort.SelectedItem.ToString
                .BaudRate = 9600
                .ReadTimeout = 1000
                .WriteTimeout = 1000
                .Open()
                .Write(cmdStr & vbLf)
            End With
            If cmdStr <> "R" Then resp = objSerial.ReadTo(vbCrLf)
        Catch ex As Exception
            resp = ""
            commsError = True
            If commsErrorMsg Then MsgBox("TopBox is not responding!" + vbCrLf + vbCrLf + "Check COM port settings, connections, cabling and power.", vbCritical, "FocusBuddy")
            lblStatus.Text = "Ready to attempt connection..."
            lblMoving.Visible = False
            lblBacklash.Visible = False
            lblUpdating.Visible = False
            grpFocuserPresets.Enabled = False
            grpSwitches.Enabled = False
            grpHeaters.Enabled = False
            btnSyncPos.Enabled = False
            btnSync.Enabled = False
            btnReFormat.Enabled = False
            btnReset.Enabled = False
            btnTimer.Enabled = False
            Timer2.Enabled = False
            btnMiniFocuser.Enabled = False
            btnUpdate.Enabled = False
        End Try

        Try
            objSerial.Close()
        Catch ex As Exception
        End Try

        Return commsError
    End Function

    Private Sub BtnInitialise_Click(sender As Object, e As EventArgs) Handles btnInitialise.Click
        Retrieve()
    End Sub

    Private Sub BtnSyncPosSelect_Click(sender As Object, e As EventArgs) Handles btnSync.Click
        If MsgBox("Sync Current Postion with selection?", vbYesNo, "FocusBuddy") = vbNo Then Exit Sub
        If Arduino(respStr, "p" + GetPreset()) Then Exit Sub
        If Arduino(respStr, "P") Then Exit Sub
        Dim currPos As Decimal = Val(respStr)
        If currPos > nudPreset9.Maximum Then currPos = nudPreset9.Maximum
        If currPos < 1 Then currPos = 1
        txtCurrPos.Text = Format(CInt(currPos), "#,##0")
        nudCurrPos.Value = currPos
    End Sub

    Private Sub BtnSyncSelectPos_Click(sender As Object, e As EventArgs) Handles btnSyncPos.Click
        If MsgBox("Sync selection with Current Position?", vbYesNo, "FocusBuddy") = vbNo Then Exit Sub
        If radPreset0.Checked Then nudPreset0.Value = CDec(txtCurrPos.Text)
        If radPreset1.Checked Then nudPreset1.Value = CDec(txtCurrPos.Text)
        If radPreset2.Checked Then nudPreset2.Value = CDec(txtCurrPos.Text)
        If radPreset3.Checked Then nudPreset3.Value = CDec(txtCurrPos.Text)
        If radPreset4.Checked Then nudPreset4.Value = CDec(txtCurrPos.Text)
        If radPreset5.Checked Then nudPreset5.Value = CDec(txtCurrPos.Text)
        If radPreset6.Checked Then nudPreset6.Value = CDec(txtCurrPos.Text)
        If radPreset7.Checked Then nudPreset7.Value = CDec(txtCurrPos.Text)
        If radPreset8.Checked Then nudPreset8.Value = CDec(txtCurrPos.Text)
        If radPreset9.Checked Then nudPreset9.Value = CDec(txtCurrPos.Text)
        If radTarget.Checked Then nudTarget.Value = CDec(txtCurrPos.Text)
    End Sub

    Private Sub BtnGoto_Click(sender As Object, e As EventArgs) Handles btnGoto.Click
        Dim target As String = GetPreset()
        DoMove(IIf(CInt(target) < CInt(txtCurrPos.Text), "I", "O"), "g" + target)
    End Sub

    Private Sub BtnPulseOut_MouseDown(sender As Object, e As MouseEventArgs) Handles btnPulseOut.MouseDown
        If lblMoving.Visible Then Exit Sub
        DoMove("O", "O")
    End Sub

    Private Sub BtnPulseOut_MouseUp(sender As Object, e As MouseEventArgs) Handles btnPulseOut.MouseUp
        StopFocuser()
    End Sub

    Private Sub BtnPulseIn_MouseDown(sender As Object, e As MouseEventArgs) Handles btnPulseIn.MouseDown
        If lblMoving.Visible Then Exit Sub
        DoMove("I", "I")
    End Sub

    Private Sub BtnPulseIn_MouseUp(sender As Object, e As MouseEventArgs) Handles btnPulseIn.MouseUp
        StopFocuser()
    End Sub

    Private Sub BtnMoveFullyOut_Click(sender As Object, e As EventArgs) Handles btnMoveFullyOut.Click
        DoMove("O", "O")
    End Sub

    Private Sub BtnMoveFullyIn_Click(sender As Object, e As EventArgs) Handles btnMoveFullyIn.Click
        DoMove("I", "I")
    End Sub

    Private Sub BtnMoveOut_Click(sender As Object, e As EventArgs) Handles btnMoveOut.Click
        If txtCurrPos.Text = "------" Then Exit Sub
        Dim dist As String = cbxMoves.SelectedItem.ToString
        Dim value As Integer
        Dim currPos As Integer = Val(txtCurrPos.Text.Replace(",", ".")) * 1000
        If dist.Contains("Custom") Then dist = nudMove.Value.ToString
        value = Val(dist)
        If (Int(currPos / value) * value) <> currPos Then       ' Round to the nearest step
            value = Int(currPos / value) * value + value - currPos
        End If
        dist = value.ToString
        DoMove("O", "O" + dist)
    End Sub

    Private Sub BtnMoveIn_Click(sender As Object, e As EventArgs) Handles btnMoveIn.Click
        If txtCurrPos.Text = "------" Then Exit Sub
        Dim dist As String = cbxMoves.SelectedItem.ToString
        Dim value As Integer
        Dim currPos As Integer = Val(txtCurrPos.Text.Replace(",", ".")) * 1000
        If dist.Contains("Custom") Then dist = nudMove.Value.ToString
        value = Val(dist)
        If (Int(currPos / value) * value) <> currPos Then       ' Round to the nearest step
            value = currPos - Int(currPos / value) * value
        End If
        dist = value.ToString
        DoMove("I", "I" + dist)
    End Sub

    Private Sub BtnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        StopFocuser()
    End Sub

    Public Sub StopFocuser()
        Arduino(respStr, "Q")
        ServiceTimer()
    End Sub

    Public Sub DoMove(targDir As String, moveCmd As String)
        If Arduino(respStr, "~") Then Exit Sub
        If respStr = "0" Then
            updateButtons()
            MsgBox("MOVE ABORTED! No power detected for the Focuser", vbCritical, "FocusBuddy TopBox")
            Exit Sub
        End If
        txtLastMove.Text = IIf(targDir = "I", "<IN", "OUT>")
        If Arduino(respStr, "L") Then Exit Sub
        If Not radBacklashDisabled.Checked AndAlso targDir <> respStr Then
            ' Deal with backlash
            Dim backlashCmd As String = ""
            If targDir = "O" Then If radOutward.Checked Or radBothWays.Checked Then backlashCmd = "O"
            If targDir = "I" Then If radInward.Checked Or radBothWays.Checked Then backlashCmd = "I"
            If backlashCmd <> "" Then                               ' Act if necessary
                lblBacklash.Visible = True                          ' Display "BACKLASH"
                If Arduino(respStr, "P") Then Exit Sub
                Dim oldPos As String = respStr                      ' Remember current position
                If Arduino(respStr, backlashCmd + nudBacklash.Value.ToString) Then Exit Sub ' Soak up the backlash
                Threading.Thread.Sleep(CInt(nudBacklash.Value))     ' Wait for backlash period
                Do
                    If Arduino(respStr, "M") Then Exit Sub
                Loop While respStr = "1"                             ' Wait for the focuser to stop moving
                If Arduino(respStr, "p" + oldPos) Then Exit Sub
                lblBacklash.Visible = False                          ' Hide "BACKLASH"
            End If
            ' Backlash dealt with
        End If
        txtLastMove.Text = IIf(targDir = "I", "<IN", "OUT>")
        'moveCmd = moveCmd.ToLower()
        If Arduino(respStr, moveCmd) Then Exit Sub
        ServiceTimer()
    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If btnUpdate.Enabled = False Then Exit Sub
        If notMoving = False Then Exit Sub
        updateArduino = True
        WriteSettingsFile()
        lblUpdating.Visible = True
        If CDec(resp(0)) <> nudPreset0.Value Then If Arduino(respStr, "z" + CStr(nudPreset0.Value) + "e0") Then Exit Sub
        If CDec(resp(1)) <> nudPreset1.Value Then If Arduino(respStr, "z" + CStr(nudPreset1.Value) + "e1") Then Exit Sub
        If CDec(resp(2)) <> nudPreset2.Value Then If Arduino(respStr, "z" + CStr(nudPreset2.Value) + "e2") Then Exit Sub
        If CDec(resp(3)) <> nudPreset3.Value Then If Arduino(respStr, "z" + CStr(nudPreset3.Value) + "e3") Then Exit Sub
        If CDec(resp(4)) <> nudPreset4.Value Then If Arduino(respStr, "z" + CStr(nudPreset4.Value) + "e4") Then Exit Sub
        If CDec(resp(5)) <> nudPreset5.Value Then If Arduino(respStr, "z" + CStr(nudPreset5.Value) + "e5") Then Exit Sub
        If CDec(resp(6)) <> nudPreset6.Value Then If Arduino(respStr, "z" + CStr(nudPreset6.Value) + "e6") Then Exit Sub
        If CDec(resp(7)) <> nudPreset7.Value Then If Arduino(respStr, "z" + CStr(nudPreset7.Value) + "e7") Then Exit Sub
        If CDec(resp(8)) <> nudPreset8.Value Then If Arduino(respStr, "z" + CStr(nudPreset8.Value) + "e8") Then Exit Sub
        If CDec(resp(9)) <> nudPreset9.Value Then If Arduino(respStr, "z" + CStr(nudPreset9.Value) + "e9") Then Exit Sub
        If CDec(resp(20)) <> nudCurrPos.Value Then If Arduino(respStr, "p" + CStr(nudCurrPos.Value)) Then Exit Sub
        If resp(11) <> txtName1.Text Then If Arduino(respStr, "n1" + txtName1.Text + "#") Then Exit Sub
        If resp(12) <> txtName2.Text Then If Arduino(respStr, "n2" + txtName2.Text + "#") Then Exit Sub
        If resp(13) <> txtName3.Text Then If Arduino(respStr, "n3" + txtName3.Text + "#") Then Exit Sub
        If resp(14) <> txtName4.Text Then If Arduino(respStr, "n4" + txtName4.Text + "#") Then Exit Sub
        If resp(15) <> txtName5.Text Then If Arduino(respStr, "n5" + txtName5.Text + "#") Then Exit Sub
        If resp(16) <> txtName6.Text Then If Arduino(respStr, "n6" + txtName6.Text + "#") Then Exit Sub
        If resp(17) <> txtName7.Text Then If Arduino(respStr, "n7" + txtName7.Text + "#") Then Exit Sub
        If resp(18) <> txtName8.Text Then If Arduino(respStr, "n8" + txtName8.Text + "#") Then Exit Sub
        If Arduino(respStr, "p" + nudCurrPos.Value.ToString) Then Exit Sub
        txtCurrPos.Text = Format(CInt(nudCurrPos.Value), "#,##0")
        btnUpdate.Enabled = False
        lblUpdating.Visible = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ServiceTimer()
    End Sub

    Sub ServiceTimer()
        Dim currPos As Decimal
        'Me.TopMost = False
        Arduino(respStr, "M")
        If respStr <> "1" Then
            Timer1.Stop()
            lblMoving.Visible = False
            notMoving = True
            btnInitialise.Enabled = True
            btnReFormat.Enabled = True
            btnSync.Enabled = True
            btnReset.Enabled = True
            btnSync.Enabled = True
            btnSyncPos.Enabled = True
            ComboBoxComPort.Enabled = True
            grpFocuserPresets.Enabled = True
            grpBacklash.Enabled = True
            grpSwitches.Enabled = True
            grpHeaters.Enabled = True
            chkRevDir.Enabled = True
            nudCurrPos.Enabled = True
            nudCurrPos.Value = CDec(txtCurrPos.Text)
            If Arduino(respStr, "L") Then
                txtLastMove.Text = "---"
                txtCurrPos.Text = "------"
                Form2Update()
                Exit Sub
            End If
            'If Not Arduino(respStr, "L") Then txtLastMove.Text = IIf(respStr = "I", "<IN", "OUT>")
            txtLastMove.Text = IIf(respStr = "I", "<IN", "OUT>")
        ElseIf notMoving Then
            lblMoving.Visible = True
            Timer1.Interval = 1000
            Timer1.Start()
            btnInitialise.Enabled = False
            btnSync.Enabled = False
            btnReFormat.Enabled = False
            ComboBoxComPort.Enabled = True
            grpBacklash.Enabled = False
            chkRevDir.Enabled = False
            nudCurrPos.Enabled = False
            notMoving = False
        End If

        If Arduino(respStr, "P") Then
            txtLastMove.Text = "---"
            txtCurrPos.Text = "------"
            Form2Update()
            Exit Sub
        End If
        'If Not Arduino(respStr, "P") Then currPos = Val(respStr)
        currPos = Val(respStr)
        If currPos > nudPreset9.Maximum Then currPos = nudPreset9.Maximum
        If currPos < 1 Then currPos = 1
        txtCurrPos.Text = Format(CInt(currPos), "#,##0")
        Form2Update()
    End Sub

    Private Function GetPreset() As String
        Dim preset As Decimal = nudCurrPos.Value
        If radTarget.Checked Then preset = nudTarget.Value
        If radPreset0.Checked Then preset = nudPreset0.Value
        If radPreset1.Checked Then preset = nudPreset1.Value
        If radPreset2.Checked Then preset = nudPreset2.Value
        If radPreset3.Checked Then preset = nudPreset3.Value
        If radPreset4.Checked Then preset = nudPreset4.Value
        If radPreset5.Checked Then preset = nudPreset5.Value
        If radPreset6.Checked Then preset = nudPreset6.Value
        If radPreset7.Checked Then preset = nudPreset7.Value
        If radPreset8.Checked Then preset = nudPreset8.Value
        If radPreset9.Checked Then preset = nudPreset9.Value
        If preset < 1 Then preset = 1
        If preset > nudPreset9.Value Then preset = nudPreset9.Value
        Return preset
    End Function

    Private Sub TxtName1_TextChanged(sender As Object, e As EventArgs) Handles txtName1.TextChanged
        If notMoving Then btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName2_TextChanged(sender As Object, e As EventArgs) Handles txtName2.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName3_TextChanged(sender As Object, e As EventArgs) Handles txtName3.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName4_TextChanged(sender As Object, e As EventArgs) Handles txtName4.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName5_TextChanged(sender As Object, e As EventArgs) Handles txtName5.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName6_TextChanged(sender As Object, e As EventArgs) Handles txtName6.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName7_TextChanged(sender As Object, e As EventArgs) Handles txtName7.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub TxtName8_TextChanged(sender As Object, e As EventArgs) Handles txtName8.TextChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudCurrPos_ValueChanged(sender As Object, e As EventArgs) Handles nudCurrPos.ValueChanged
        If lblMoving.Visible = False Then btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset0_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset0.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset1_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset1.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset2_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset2.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset3_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset3.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset4_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset4.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset5_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset5.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset6_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset6.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset7_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset7.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset8_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset8.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub NudPreset9_ValueChanged(sender As Object, e As EventArgs) Handles nudPreset9.ValueChanged
        btnUpdate.Enabled = True
    End Sub

    Private Sub ComboBoxComPort_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxComPort.SelectedIndexChanged
        comPort = ComboBoxComPort.SelectedItem
        lblStatus.Text = "Ready to attempt connection..."
        WriteSettingsFile()
    End Sub

    Private Sub ChkConnectOnStartUp_CheckedChanged(sender As Object, e As EventArgs) Handles chkConnectOnStartUp.CheckedChanged
        WriteSettingsFile()
    End Sub

    Private Sub RadBacklashDisabled_CheckedChanged(sender As Object, e As EventArgs) Handles radBacklashDisabled.CheckedChanged
        WriteSettingsFile()
    End Sub

    Private Sub RadOutward_CheckedChanged(sender As Object, e As EventArgs) Handles radOutward.CheckedChanged
        WriteSettingsFile()
    End Sub

    Private Sub RadInward_CheckedChanged(sender As Object, e As EventArgs) Handles radInward.CheckedChanged
        WriteSettingsFile()
    End Sub

    Private Sub NudBacklash_ValueChanged(sender As Object, e As EventArgs) Handles nudBacklash.ValueChanged
        WriteSettingsFile()
    End Sub

    Private Sub NudMove_ValueChanged(sender As Object, e As EventArgs) Handles nudMove.ValueChanged
        cbxMoves.Items.Clear()
        cbxMoves.Items.Add(nudMove.Value.ToString + " (Custom)")
        cbxMoves.Items.Add("100")
        cbxMoves.Items.Add("200")
        cbxMoves.Items.Add("500")
        cbxMoves.Items.Add("1000")
        cbxMoves.Items.Add("2000")
        cbxMoves.Items.Add("5000")
        cbxMoves.SelectedIndex = 0
        WriteSettingsFile()
    End Sub

    Private Sub GetSettings()
        Dim line As String
        Dim valStr As String
        Dim errorFlag As Boolean

        Do
            canUpdate = False
            If File.Exists(settingsFile) = False Then
                chkConnectOnStartUp.Checked = False
                radBacklashDisabled.Checked = True
                radInward.Checked = False
                radOutward.Checked = False
                nudBacklash.Value = 1000
                WriteSettingsFile()
                canUpdate = True
                Exit Sub
            End If

            chkConnectOnStartUp.Checked = False
            radBacklashDisabled.Checked = True
            nudBacklash.Value = 1000

            errorFlag = False
            FileOpen(1, settingsFile, OpenMode.Input)
            While EOF(1) = False
                line = LineInput(1)
                valStr = Trim(Mid(line, InStr(line, "=") + 1, 256))
                Select Case Trim(Strings.Left(line, InStr(line, "=") - 1))
                    Case "COMPort"
                        comPort = valStr
                    Case "ConnectOnStartUp"
                        If valStr = "True" Then chkConnectOnStartUp.Checked = True
                    Case "BacklashMode"
                        If valStr = "Inwards" Then radInward.Checked = True
                        If valStr = "Outwards" Then radInward.Checked = True
                        If valStr = "BothWays" Then radBothWays.Checked = True
                        If valStr = "Disabled" Then radBacklashDisabled.Checked = True
                    Case "BacklashAllowance"
                        If CInt(valStr) >= 0 And CInt(valStr) <= 10000 Then nudBacklash.Value = Val(valStr)
                    Case "UserMoveAmount"
                        If CInt(valStr) >= 0 And CInt(valStr) <= nudPreset9.Value Then nudMove.Value = Val(valStr)
                    Case "TimerCloseRoof"
                        timerCloseRoof = (valStr = "True")
                    Case Else
                        'errorFlag = True    ' settings.ini is not in correct format
                End Select
            End While
            FileClose(1)
            If errorFlag Then File.Delete(settingsFile)
        Loop While errorFlag
        canUpdate = True
    End Sub

    Private Sub btnGetPresets_Click(sender As Object, e As EventArgs) Handles btnGetPresets.Click
        Dim line As String
        Dim valStr As String
        If Not updateArduino AndAlso File.Exists(settingsFile) Then
            FileOpen(1, settingsFile, OpenMode.Input)
            While EOF(1) = False
                line = LineInput(1)
                valStr = Trim(Mid(line, InStr(line, "=") + 1, 256))
                Select Case Trim(Strings.Left(line, InStr(line, "=") - 1))
                    Case "Preset0 Name"
                        txtName0.Text = valStr
                    Case "Preset0 Position"
                        nudPreset0.Value = CDec(valStr)
                    Case "Preset1 Name"
                        txtName1.Text = valStr
                    Case "Preset1 Position"
                        nudPreset1.Value = CDec(valStr)
                    Case "Preset2 Name"
                        txtName2.Text = valStr
                    Case "Preset2 Position"
                        nudPreset2.Value = CDec(valStr)
                    Case "Preset3 Name"
                        txtName3.Text = valStr
                    Case "Preset3 Position"
                        nudPreset3.Value = CDec(valStr)
                    Case "Preset4 Name"
                        txtName4.Text = valStr
                    Case "Preset4 Position"
                        nudPreset4.Value = CDec(valStr)
                    Case "Preset5 Name"
                        txtName5.Text = valStr
                    Case "Preset5 Position"
                        nudPreset5.Value = CDec(valStr)
                    Case "Preset6 Name"
                        txtName6.Text = valStr
                    Case "Preset6 Position"
                        nudPreset6.Value = CDec(valStr)
                    Case "Preset6 Name"
                        txtName6.Text = valStr
                    Case "Preset7 Position"
                        nudPreset7.Value = CDec(valStr)
                    Case "Preset7 Name"
                        txtName8.Text = valStr
                    Case "Preset8 Position"
                        nudPreset8.Value = CDec(valStr)
                    Case "Preset8 Name"
                        txtName8.Text = valStr
                    Case "Preset8 Position"
                        nudPreset8.Value = CDec(valStr)
                    Case "Preset9 Name"
                        txtName9.Text = valStr
                    Case "Preset9 Position"
                        nudPreset9.Value = CDec(valStr)
                End Select
            End While
            FileClose(1)
        End If
    End Sub

    Private Sub WriteSettingsFile()
        Dim line As String
        Dim valStr As String
        Dim preset(9, 1) As String
        If canUpdate = False Then Exit Sub

        preset(0, 0) = txtName0.Text
        preset(0, 1) = nudPreset0.Value.ToString
        preset(1, 0) = txtName1.Text
        preset(1, 1) = nudPreset1.Value.ToString
        preset(2, 0) = txtName2.Text
        preset(2, 1) = nudPreset2.Value.ToString
        preset(3, 0) = txtName3.Text
        preset(3, 1) = nudPreset3.Value.ToString
        preset(4, 0) = txtName4.Text
        preset(4, 1) = nudPreset4.Value.ToString
        preset(5, 0) = txtName5.Text
        preset(5, 1) = nudPreset5.Value.ToString
        preset(6, 0) = txtName6.Text
        preset(6, 1) = nudPreset6.Value.ToString
        preset(7, 0) = txtName7.Text
        preset(7, 1) = nudPreset7.Value.ToString
        preset(8, 0) = txtName8.Text
        preset(8, 1) = nudPreset8.Value.ToString
        preset(9, 0) = txtName9.Text
        preset(9, 1) = nudPreset9.Value.ToString

        If Not My.Computer.FileSystem.DirectoryExists(settingsPath) Then My.Computer.FileSystem.CreateDirectory(settingsPath)

        If Not updateArduino AndAlso File.Exists(settingsFile) Then
            FileOpen(1, settingsFile, OpenMode.Input)
            While EOF(1) = False
                line = LineInput(1)
                valStr = Trim(Mid(line, InStr(line, "=") + 1, 256))
                Select Case Trim(Strings.Left(line, InStr(line, "=") - 1))
                    Case "Preset0 Name"
                        preset(0, 0) = valStr
                    Case "Preset0 Position"
                        preset(0, 1) = valStr
                    Case "Preset1 Name"
                        preset(1, 0) = valStr
                    Case "Preset1 Position"
                        preset(1, 1) = valStr
                    Case "Preset2 Name"
                        preset(2, 0) = valStr
                    Case "Preset2 Position"
                        preset(2, 1) = valStr
                    Case "Preset3 Name"
                        preset(3, 0) = valStr
                    Case "Preset3 Position"
                        preset(3, 1) = valStr
                    Case "Preset4 Name"
                        preset(4, 0) = valStr
                    Case "Preset4 Position"
                        preset(4, 1) = valStr
                    Case "Preset5 Name"
                        preset(5, 0) = valStr
                    Case "Preset5 Position"
                        preset(5, 1) = valStr
                    Case "Preset6 Name"
                        preset(6, 0) = valStr
                    Case "Preset6 Position"
                        preset(6, 1) = valStr
                    Case "Preset7 Name"
                        preset(7, 0) = valStr
                    Case "Preset7 Position"
                        preset(7, 1) = valStr
                    Case "Preset8 Name"
                        preset(8, 0) = valStr
                    Case "Preset8 Position"
                        preset(8, 1) = valStr
                    Case "Preset9 Name"
                        preset(9, 0) = valStr
                    Case "Preset9 Position"
                        preset(9, 1) = valStr
                End Select
            End While
            FileClose(1)
        End If

        File.Delete(settingsFile)
        Using sw As New StreamWriter(settingsFile)
            sw.WriteLine("COMPort           = " + comPort)
            sw.WriteLine("ConnectOnStartUp  = " + chkConnectOnStartUp.Checked.ToString)
            If radInward.Checked = True Then sw.WriteLine("BacklashMode      = Inwards")
            If radOutward.Checked = True Then sw.WriteLine("BacklashMode      = Outwards")
            If radBothWays.Checked = True Then sw.WriteLine("BacklashMode      = BothWays")
            If radBacklashDisabled.Checked = True Then sw.WriteLine("BacklashMode      = Disabled")
            sw.WriteLine("BacklashAllowance = " + nudBacklash.Value.ToString)
            sw.WriteLine("UserMoveAmount    = " + nudMove.Value.ToString)
            sw.WriteLine("TimerCloseRoof    = " + timerCloseRoof.ToString)
            For i = 0 To 9
                sw.WriteLine("Preset" + i.ToString + " Name      = " + preset(i, 0))
                sw.WriteLine("Preset" + i.ToString + " Position  = " + preset(i, 1))
            Next
        End Using
        updateArduino = False
    End Sub

    Private Sub ChkRevDir_CheckedChanged(sender As Object, e As EventArgs) Handles chkRevDir.CheckedChanged
        If chkRevDir.Checked Then If Arduino(respStr, "<") Then Exit Sub
        If Not chkRevDir.Checked Then If Arduino(respStr, ">") Then Exit Sub
    End Sub

    Private Sub btnReFormat_Click(sender As Object, e As EventArgs) Handles btnReFormat.Click
        If ComboBoxComPort.SelectedIndex = -1 Then
            MsgBox("Please select COM port for FocusBuddy controller",, "FocusBuddy")
            Exit Sub
        End If
        commsError = False
        commsErrorMsg = True
        If Arduino(respStr, "Q") Then Exit Sub

        If MsgBox("Reformat EEPROM - are sure?", vbYesNo, "FocusBuddy") = vbNo Then Exit Sub
        If MsgBox("Do you want to change you mind?", vbYesNo, "FocusBuddy") = vbYes Then Exit Sub
        If MsgBox("Click OK to reformat the EEPROM.", vbOKCancel, "FocusBuddy") = vbCancel Then Exit Sub
        commsErrorMsg = False
        Arduino(respStr, "W")
        Arduino(respStr, "F")
        Arduino(respStr, "R")
        commsErrorMsg = True
        MsgBox("EEPROM has been reformatted", vbOK, "FocusBuddy")
        Retrieve()
    End Sub

    Private Sub GitHubLogo_Click(sender As Object, e As EventArgs) Handles GitHubLogo.Click
        Dim Browser As New Process
        Browser.StartInfo.FileName = "https: //github.com/kickitharder/FocusBuddy"
        Browser.StartInfo.UseShellExecute = True
        Browser.StartInfo.RedirectStandardOutput = False
        Try
            Browser.Start()
        Catch ex As Exception

        End Try
        Browser.Dispose()
    End Sub

    Private Sub CMHASDLogo_Click(sender As Object, e As EventArgs) Handles CMHASDLogo.Click
        Dim Browser As New Process
        Browser.StartInfo.FileName = "https://crayfordmanorastro.com/"
        Browser.StartInfo.UseShellExecute = True
        Browser.StartInfo.RedirectStandardOutput = False
        Try
            Browser.Start()
        Catch ex As Exception

        End Try
        Browser.Dispose()
    End Sub

    Private Sub btnMiniFocuser_Click(sender As Object, e As EventArgs) Handles btnMiniFocuser.Click
        Me.Visible = False
        Timer2.Stop()
        Form2Update()
        Form2.ShowDialog()
        Me.Visible = True
        TimerUpdate()
    End Sub

    Private Sub Form2Update()
        If Form2.Visible = False Then Exit Sub
        Form2.infoUpdate(IIf(notMoving, "FocusBuddy", "Moving..."), txtCurrPos.Text, txtLastMove.Text)
    End Sub

    Private Sub tbrTelescope_ValueChanged(sender As Object, e As EventArgs) Handles tbrTelescope.ValueChanged
        lblTelescopeHeater.Text = Str(Int(tbrTelescope.Value / 10 + 0.5) * 10) + "%"
        If lblTelescopeHeater.Text = " 0%" Then
            lblTelescopeHeater.Text = "OFF"
            lblTelescopeHeater.BackColor = Color.Red
            lblTelescopeHeater.ForeColor = Color.White
        Else
            lblTelescopeHeater.BackColor = Color.Lime
            lblTelescopeHeater.ForeColor = Color.Black
        End If
    End Sub

    Private Sub tbrTelescope_MouseUp(sender As Object, e As MouseEventArgs) Handles tbrTelescope.MouseUp
        tbrTelescope.Value = Int(tbrTelescope.Value / 10 + 0.5) * 10
        Arduino(respStr, "#B" + Trim(Str(Int(255 * tbrTelescope.Value / 100))))
        updateButtons()
    End Sub

    Private Sub tbrGuidescope_ValueChanged(sender As Object, e As EventArgs) Handles tbrGuidescope.ValueChanged
        lblGuidescopeHeater.Text = Str(Int(tbrGuidescope.Value / 10 + 0.5) * 10) + "%"
        If lblGuidescopeHeater.Text = " 0%" Then
            lblGuidescopeHeater.Text = "OFF"
            lblGuidescopeHeater.BackColor = Color.Red
            lblGuidescopeHeater.ForeColor = Color.White
        Else
            lblGuidescopeHeater.BackColor = Color.Lime
            lblGuidescopeHeater.ForeColor = Color.Black
        End If
    End Sub

    Private Sub tbrGuidescope_MouseUp(sender As Object, e As MouseEventArgs) Handles tbrGuidescope.MouseUp
        tbrGuidescope.Value = Int(tbrGuidescope.Value / 10 + 0.5) * 10
        Arduino(respStr, "#A" + Trim(Str(Int(255 * tbrGuidescope.Value / 100))))
        updateButtons()
    End Sub

    Private Sub btnPower_Click(sender As Object, e As EventArgs) Handles btnPower.Click
        If btnPower.Text = "ON" Then
            If MsgBox("Are you sure you want to turn off the Power?", vbYesNoCancel, "FocusBuddy TopBox") <> vbYes Then Exit Sub
            If Arduino(respStr, "$1+") Then Exit Sub
        Else
            If Arduino(respStr, "$1-") Then Exit Sub
        End If
        System.Threading.Thread.Sleep(100)
        updateButtons()
    End Sub

    Private Sub btnStepper_Click(sender As Object, e As EventArgs) Handles btnStepper.Click
        If btnStepper.Text = "ON" Then
            If Arduino(respStr, "$3+") Then Exit Sub
        Else
            If Arduino(respStr, "$3-") Then Exit Sub
        End If
        updateButtons()
    End Sub

    Private Sub btnELPanel_Click(sender As Object, e As EventArgs) Handles btnELPanel.Click
        If btnELPanel.Text = "ON" Then
            If Arduino(respStr, "$2-") Then Exit Sub
        Else
            If Arduino(respStr, "$2+") Then Exit Sub
        End If
        updateButtons()
    End Sub

    Private Sub updateButtons()
        Dim power As String = ""
        If Arduino(power, "~") Then Exit Sub
        If power = "0" Then
            btnPower.Text = "OFF"
            btnPower.BackColor = Color.Red
            btnPower.ForeColor = Color.White
            If Arduino(respStr, "$1+") Then Exit Sub
        Else
            btnPower.Text = "ON"
            btnPower.BackColor = Color.Lime
            btnPower.ForeColor = Color.Black
            If Arduino(respStr, "$1-") Then Exit Sub
        End If

        If Arduino(respStr, "$2=") Then Exit Sub
        btnELPanel.BackColor = Color.Red
        btnELPanel.ForeColor = Color.White
        If respStr = "-" Then
            btnELPanel.Text = "OFF"
        Else
            btnELPanel.Text = "ON"
            If power = "1" Then
                btnELPanel.BackColor = Color.Lime
                btnELPanel.ForeColor = Color.Black
            End If
        End If

        If Arduino(respStr, "$3=") Then Exit Sub
        btnStepper.BackColor = Color.Red
        btnStepper.ForeColor = Color.White
        If respStr = "+" Then
            btnStepper.Text = "OFF"
        Else
            btnStepper.Text = "ON"
            If power = "1" Then
                btnStepper.BackColor = Color.Lime
                btnStepper.ForeColor = Color.Black
            End If
        End If

        If Arduino(respStr, "#A=") Then Exit Sub
        tbrGuidescope.Value = Int(100 * Val(respStr) / 255 + 0.5)
        lblGuidescopeHeater.Text = Str(tbrGuidescope.Value) + "%"
        lblGuidescopeHeater.BackColor = Color.Red
        lblGuidescopeHeater.ForeColor = Color.White
        If lblGuidescopeHeater.Text = " 0%" Then
            lblGuidescopeHeater.Text = "OFF"
        Else
            If power = "1" Then
                lblGuidescopeHeater.BackColor = Color.Lime
                lblGuidescopeHeater.ForeColor = Color.Black
            End If
        End If

        If Arduino(respStr, "#B=") Then Exit Sub
        tbrTelescope.Value = Int(100 * Val(respStr) / 255 + 0.5)
        lblTelescopeHeater.Text = Str(tbrTelescope.Value) & "%"
        lblTelescopeHeater.BackColor = Color.Red
        lblTelescopeHeater.ForeColor = Color.White
        If lblTelescopeHeater.Text = " 0%" Then
            lblTelescopeHeater.Text = "OFF"
        Else
            If power = "1" Then
                lblTelescopeHeater.BackColor = Color.Lime
                lblTelescopeHeater.ForeColor = Color.Black
            End If
        End If
    End Sub

    Private Sub Reset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        If MsgBox("Are you sure you want to reset the Arduino?", vbYesNoCancel, "FocusBuddy TopBox") <> vbYes Then Exit Sub
        Arduino(respStr, "R")                   ' Reset Adruino and it's clock
        System.Threading.Thread.Sleep(1000)
        Retrieve()
    End Sub

    Private Sub btnTimer_Click(sender As Object, e As EventArgs) Handles btnTimer.Click
        Dim powerTimer As Integer
        If btnTimer.Text = "Start Timer" Then
            powerTimer = nudHours.Value * 60 * 60000 + nudMins.Value * 60000
            If Arduino(respStr, "X" + Trim(Str(powerTimer))) Then Exit Sub
        Else
            If Arduino(respStr, "X0") Then Exit Sub
        End If
        TimerUpdate()
    End Sub

    Private Sub TimerUpdate()
        If Arduino(respStr, "x") Then Exit Sub
        If respStr = "0" Then
            Timer2.Stop()
            btnTimer.Text = "Start Timer"
            btnTimer.BackColor = Color.Red
            btnTimer.ForeColor = Color.White
            updateButtons()
            If timerCloseRoof Then CloseRoof()
            Exit Sub
        End If
        btnTimer.BackColor = Color.Lime
        btnTimer.ForeColor = Color.Black
        Dim millis As Integer = Val(respStr)
        Dim days As Integer = Int(millis / 86400000)
        millis -= days * 86400000
        Dim hours As Integer = Int(millis / 3600000)
        millis -= hours * 3600000
        Dim mins As Integer = Int(millis / 60000)
        millis -= mins * 60000
        Dim secs As Integer = Int(millis / 1000)
        Dim btnText As String
        btnText = IIf(days < 10, "0", "") + Trim(Str(days)) + "d "
        btnText += IIf(hours < 10, "0", "") + Trim(Str(hours)) + "h "
        btnText += IIf(mins < 10, "0", "") + Trim(Str(mins)) + "m "
        btnText += IIf(secs < 10, "0", "") + Trim(Str(secs)) + "s"
        btnTimer.Text = btnText
        Timer2.Interval = 1000
        Timer2.Start()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        TimerUpdate()
    End Sub

    Private Sub btnSettings_Click(sender As Object, e As EventArgs) Handles btnSettings.Click
        'Dim RBSettings As New Form
        btnUpdate.Enabled = True
        RBSettings.ShowDialog()
    End Sub

    Private Sub btnRBopen_Click(sender As Object, e As EventArgs) Handles btnRBopen.Click
        lblRBstatus.Text = "Opening 0%"
        btnRBopen.Enabled = False
        btnRBclose.Enabled = False
        btnSettings.Enabled = False
        btnRBstop.Text = "STOP"
        System.Windows.Forms.Application.DoEvents()
        ' If RBCommand("O") Then Exit Sub
        RBCommand("O")
        StatusField()
        timerFlag = True
        Timer3.Interval = 800
        Timer3.Enabled = True
        Timer3.Start()
    End Sub

    Private Sub btnRBclose_Click(sender As Object, e As EventArgs) Handles btnRBclose.Click
        CloseRoof()
    End Sub

    Private Sub CloseRoof()
        lblRBstatus.Text = "Closing 0%"
        btnRBopen.Enabled = False
        btnRBclose.Enabled = False
        btnSettings.Enabled = False
        btnRBstop.Text = "STOP"
        System.Windows.Forms.Application.DoEvents()
        ' If RBCommand("C") Then Exit Sub
        RBCommand("C")
        StatusField()
        timerFlag = True
        Timer3.Interval = 800
        Timer3.Enabled = True
        Timer3.Start()
    End Sub

    Private Sub btnRBstop_Click(sender As Object, e As EventArgs) Handles btnRBstop.Click
        Timer3.Stop()
        If btnRBstop.Text = "STOP" Then
            lblRBstatus.Text = "Stopping"
            System.Windows.Forms.Application.DoEvents()
            If RBCommand("H") Then Exit Sub
        End If
        btnRBopen.Enabled = True
        btnRBclose.Enabled = True
        btnSettings.Enabled = True
        btnRBstop.Text = "Check"
        RBstatus()
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Timer3.Stop()
        StatusField()
    End Sub

    Private Sub StatusField()
        If RBCommand("s") Then Exit Sub
        Select Case (respStr)
            Case "C"
                lblRBstatus.Text = "Closed"
                btnRBopen.Enabled = True
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "c"
                If RBCommand("g") Then Exit Select
                lblRBstatus.Text = "Closing " + respStr + "%"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = False
                btnRBstop.Text = "STOP"
                If timerFlag Then Timer3.Start()
                Exit Select
            Case "O"
                lblRBstatus.Text = "Open"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = True
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "o"
                If RBCommand("g") Then Exit Select
                lblRBstatus.Text = "Opening " + respStr + "%"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = False
                btnRBstop.Text = "STOP"
                If timerFlag Then Timer3.Start()
                Exit Select
            Case "h"
                lblRBstatus.Text = "Partly open"
                btnRBopen.Enabled = True
                btnRBclose.Enabled = True
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "H"
                lblRBstatus.Text = "Partly closed"
                btnRBopen.Enabled = True
                btnRBclose.Enabled = True
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "p"
                lblRBstatus.Text = "Parking (open)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = False
                btnRBstop.Text = "STOP"
                timerFlag = False
                Exit Select
            Case "P"
                lblRBstatus.Text = "Parking (close)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = False
                btnRBstop.Text = "STOP"
                timerFlag = False
                Exit Select
            Case "b"
                lblRBstatus.Text = "No Power (open)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "B"
                lblRBstatus.Text = "No Power (close)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "t"
                lblRBstatus.Text = "Timed-out (op)"
                btnRBopen.Enabled = True
                btnRBclose.Enabled = True
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "T"
                lblRBstatus.Text = "Timed-out (cl)"
                btnRBopen.Enabled = True
                btnRBclose.Enabled = True
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "r"
                lblRBstatus.Text = "Raining (open)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "R"
                lblRBstatus.Text = "Raining (close)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = False
                btnRBstop.Text = "STOP"
                timerFlag = False
                Exit Select
            Case "s"
                lblRBstatus.Text = "Not safe (open)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "S"
                lblRBstatus.Text = "Not safe (close)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "l"
                lblRBstatus.Text = "No cxn (open)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case "L"
                lblRBstatus.Text = "No cxn (close)"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
            Case Else
                lblRBstatus.Text = "Unknown"
                btnRBopen.Enabled = False
                btnRBclose.Enabled = False
                btnSettings.Enabled = True
                btnRBstop.Text = "Check"
                timerFlag = False
                Exit Select
        End Select
        System.Windows.Forms.Application.DoEvents()
    End Sub

    Private Sub RBstatus()
        grpRBcontrols.Enabled = False
        If RBCommand("^") Then Exit Sub           ' Quit if there is no Bluetooth connection with the RoofBuddy controller
        If respStr = "0" Then Exit Sub
        If RBCommand("e") Then Exit Sub
        If respStr <> "e" Then Exit Sub          ' Is RoofBuddy controller responding?
        grpRBcontrols.Enabled = True

        If RBCommand("b") Then Exit Sub
        System.Windows.Forms.Application.DoEvents()
        If Val(respStr) >= 12.4 Then
            lblBattery.ForeColor = Color.ForestGreen
            lblBattery.Text = respStr + "V  Good"
        ElseIf Val(respStr) >= 11.0 Then
            lblBattery.ForeColor = Color.Indigo
            lblBattery.Text = respStr + "V  Charge"
        ElseIf Val(respStr) >= 6.0 Then
            lblBattery.ForeColor = Color.Magenta
            lblBattery.Text = respStr + "V  Flat"
        Else
            lblBattery.ForeColor = Color.Red
            lblBattery.Text = respStr + "V No Power"
        End If

        If RBCommand("r") Then Exit Sub
        If respStr = "0" Then
            lblRain.Text = "Dry"
            lblRain.ForeColor = Color.ForestGreen
        Else
            lblRain.Text = "Wet"
            lblRain.ForeColor = Color.Red
        End If

        If RBCommand("@T") Then Exit Sub
        respStr = (Int((Val(respStr) + 0.5) / 10) / 10).ToString
        If Not respStr.Contains(".") Then respStr += ".0"
        lblTemp.Text = respStr + "�C"

        If RBCommand("l") Then Exit Sub
        If respStr = "0" Then
            lblLX200status.Text = "Not connected"
            btnRBopen.Enabled = False
            btnRBclose.Enabled = False
            btnRBstop.Text = "Check"
        Else
            lblLX200status.Text = "Connected"
        End If

        StatusField()
    End Sub

    Private Function RBCommand(cmdStr As String) As Boolean
        If cmdStr = "" Then Return ""
        Dim objSerial As New SerialPort
        Dim rbCommsError = False
        If cmdStr.StartsWith("@") Then
            cmdStr += vbLf
        Else
            cmdStr = "^" + Asc(cmdStr.Substring(0, 1)).ToString + IIf(cmdStr.Length > 1, cmdStr.Substring(1), "") + "$"
        End If

        Try
            With objSerial
                .PortName = comPort
                .BaudRate = 9600
                .ReadTimeout = 5000
                .WriteTimeout = 1000
                .Open()
                .Write(cmdStr)
            End With
            If cmdStr.StartsWith("@") Then
                respStr = objSerial.ReadTo(vbCrLf)
            Else
                respStr = objSerial.ReadTo("$")
            End If
        Catch ex As Exception
            rbCommsError = True
            respStr = ""
        End Try

        objSerial.Close()
        objSerial.Dispose()
        Return rbCommsError
    End Function

End Class