<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ComboBoxComPort = New System.Windows.Forms.ComboBox()
        Me.grpFocuserPresets = New System.Windows.Forms.GroupBox()
        Me.btnGetPresets = New System.Windows.Forms.Button()
        Me.lblBacklash = New System.Windows.Forms.Label()
        Me.txtLastMove = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblUpdating = New System.Windows.Forms.Label()
        Me.cbxMoves = New System.Windows.Forms.ComboBox()
        Me.lblRetrieve = New System.Windows.Forms.Label()
        Me.btnMoveFullyOut = New System.Windows.Forms.Button()
        Me.btnMoveOut = New System.Windows.Forms.Button()
        Me.btnPulseOut = New System.Windows.Forms.Button()
        Me.lblMoving = New System.Windows.Forms.Label()
        Me.btnPulseIn = New System.Windows.Forms.Button()
        Me.btnMoveIn = New System.Windows.Forms.Button()
        Me.btnMoveFullyIn = New System.Windows.Forms.Button()
        Me.lblCurrPos = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.nudMove = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset9 = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset8 = New System.Windows.Forms.NumericUpDown()
        Me.btnGoto = New System.Windows.Forms.Button()
        Me.nudPreset7 = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset6 = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset5 = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset4 = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset3 = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset2 = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset1 = New System.Windows.Forms.NumericUpDown()
        Me.nudPreset0 = New System.Windows.Forms.NumericUpDown()
        Me.nudCurrPos = New System.Windows.Forms.NumericUpDown()
        Me.nudTarget = New System.Windows.Forms.NumericUpDown()
        Me.radTarget = New System.Windows.Forms.RadioButton()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtCurrPos = New System.Windows.Forms.TextBox()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.radPreset9 = New System.Windows.Forms.RadioButton()
        Me.radPreset8 = New System.Windows.Forms.RadioButton()
        Me.radPreset7 = New System.Windows.Forms.RadioButton()
        Me.radPreset6 = New System.Windows.Forms.RadioButton()
        Me.radPreset5 = New System.Windows.Forms.RadioButton()
        Me.radPreset4 = New System.Windows.Forms.RadioButton()
        Me.radPreset3 = New System.Windows.Forms.RadioButton()
        Me.radPreset2 = New System.Windows.Forms.RadioButton()
        Me.radPreset1 = New System.Windows.Forms.RadioButton()
        Me.radPreset0 = New System.Windows.Forms.RadioButton()
        Me.txtName9 = New System.Windows.Forms.TextBox()
        Me.txtName8 = New System.Windows.Forms.TextBox()
        Me.txtName7 = New System.Windows.Forms.TextBox()
        Me.txtName6 = New System.Windows.Forms.TextBox()
        Me.txtName5 = New System.Windows.Forms.TextBox()
        Me.txtName4 = New System.Windows.Forms.TextBox()
        Me.txtName3 = New System.Windows.Forms.TextBox()
        Me.txtName2 = New System.Windows.Forms.TextBox()
        Me.txtName1 = New System.Windows.Forms.TextBox()
        Me.txtName0 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnSyncPos = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnInitialise = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.grpBacklash = New System.Windows.Forms.GroupBox()
        Me.radBothWays = New System.Windows.Forms.RadioButton()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.nudBacklash = New System.Windows.Forms.NumericUpDown()
        Me.radInward = New System.Windows.Forms.RadioButton()
        Me.radOutward = New System.Windows.Forms.RadioButton()
        Me.radBacklashDisabled = New System.Windows.Forms.RadioButton()
        Me.chkConnectOnStartUp = New System.Windows.Forms.CheckBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.btnSync = New System.Windows.Forms.Button()
        Me.chkRevDir = New System.Windows.Forms.CheckBox()
        Me.btnReFormat = New System.Windows.Forms.Button()
        Me.btnMiniFocuser = New System.Windows.Forms.Button()
        Me.grpSwitches = New System.Windows.Forms.GroupBox()
        Me.btnPower = New System.Windows.Forms.Button()
        Me.btnELPanel = New System.Windows.Forms.Button()
        Me.btnStepper = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.grpHeaters = New System.Windows.Forms.GroupBox()
        Me.lblGuidescopeHeater = New System.Windows.Forms.Label()
        Me.Label = New System.Windows.Forms.Label()
        Me.tbrGuidescope = New System.Windows.Forms.TrackBar()
        Me.lblTelescopeHeater = New System.Windows.Forms.Label()
        Me.tbrTelescope = New System.Windows.Forms.TrackBar()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.GitHubLogo = New System.Windows.Forms.PictureBox()
        Me.CMHASDLogo = New System.Windows.Forms.PictureBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.nudHours = New System.Windows.Forms.NumericUpDown()
        Me.nudMins = New System.Windows.Forms.NumericUpDown()
        Me.grpTimer = New System.Windows.Forms.GroupBox()
        Me.btnTimer = New System.Windows.Forms.Button()
        Me.lblMins = New System.Windows.Forms.Label()
        Me.lblHours = New System.Windows.Forms.Label()
        Me.lblMillis = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.btnRBclose = New System.Windows.Forms.Button()
        Me.btnRBopen = New System.Windows.Forms.Button()
        Me.btnRBstop = New System.Windows.Forms.Button()
        Me.grpRBcontrols = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblLX200status = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.lblRBstatus = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.lblTemp = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.lblRain = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.lblBattery = New System.Windows.Forms.Label()
        Me.btnSettings = New System.Windows.Forms.Button()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.grpFocuserPresets.SuspendLayout()
        CType(Me.nudMove, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPreset0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudCurrPos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTarget, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpBacklash.SuspendLayout()
        CType(Me.nudBacklash, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpSwitches.SuspendLayout()
        Me.grpHeaters.SuspendLayout()
        CType(Me.tbrGuidescope, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbrTelescope, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GitHubLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CMHASDLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudHours, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudMins, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpTimer.SuspendLayout()
        Me.grpRBcontrols.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboBoxComPort
        '
        Me.ComboBoxComPort.FormattingEnabled = True
        Me.ComboBoxComPort.Location = New System.Drawing.Point(16, 56)
        Me.ComboBoxComPort.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ComboBoxComPort.Name = "ComboBoxComPort"
        Me.ComboBoxComPort.Size = New System.Drawing.Size(80, 23)
        Me.ComboBoxComPort.TabIndex = 4
        '
        'grpFocuserPresets
        '
        Me.grpFocuserPresets.Controls.Add(Me.btnGetPresets)
        Me.grpFocuserPresets.Controls.Add(Me.lblBacklash)
        Me.grpFocuserPresets.Controls.Add(Me.txtLastMove)
        Me.grpFocuserPresets.Controls.Add(Me.Label14)
        Me.grpFocuserPresets.Controls.Add(Me.Label20)
        Me.grpFocuserPresets.Controls.Add(Me.lblUpdating)
        Me.grpFocuserPresets.Controls.Add(Me.cbxMoves)
        Me.grpFocuserPresets.Controls.Add(Me.lblRetrieve)
        Me.grpFocuserPresets.Controls.Add(Me.btnMoveFullyOut)
        Me.grpFocuserPresets.Controls.Add(Me.btnMoveOut)
        Me.grpFocuserPresets.Controls.Add(Me.btnPulseOut)
        Me.grpFocuserPresets.Controls.Add(Me.lblMoving)
        Me.grpFocuserPresets.Controls.Add(Me.btnPulseIn)
        Me.grpFocuserPresets.Controls.Add(Me.btnMoveIn)
        Me.grpFocuserPresets.Controls.Add(Me.btnMoveFullyIn)
        Me.grpFocuserPresets.Controls.Add(Me.lblCurrPos)
        Me.grpFocuserPresets.Controls.Add(Me.Label26)
        Me.grpFocuserPresets.Controls.Add(Me.nudMove)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset9)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset8)
        Me.grpFocuserPresets.Controls.Add(Me.btnGoto)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset7)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset6)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset5)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset4)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset3)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset2)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset1)
        Me.grpFocuserPresets.Controls.Add(Me.nudPreset0)
        Me.grpFocuserPresets.Controls.Add(Me.nudCurrPos)
        Me.grpFocuserPresets.Controls.Add(Me.nudTarget)
        Me.grpFocuserPresets.Controls.Add(Me.radTarget)
        Me.grpFocuserPresets.Controls.Add(Me.Label21)
        Me.grpFocuserPresets.Controls.Add(Me.txtCurrPos)
        Me.grpFocuserPresets.Controls.Add(Me.btnStop)
        Me.grpFocuserPresets.Controls.Add(Me.Label17)
        Me.grpFocuserPresets.Controls.Add(Me.Label16)
        Me.grpFocuserPresets.Controls.Add(Me.Label15)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset9)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset8)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset7)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset6)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset5)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset4)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset3)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset2)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset1)
        Me.grpFocuserPresets.Controls.Add(Me.radPreset0)
        Me.grpFocuserPresets.Controls.Add(Me.txtName9)
        Me.grpFocuserPresets.Controls.Add(Me.txtName8)
        Me.grpFocuserPresets.Controls.Add(Me.txtName7)
        Me.grpFocuserPresets.Controls.Add(Me.txtName6)
        Me.grpFocuserPresets.Controls.Add(Me.txtName5)
        Me.grpFocuserPresets.Controls.Add(Me.txtName4)
        Me.grpFocuserPresets.Controls.Add(Me.txtName3)
        Me.grpFocuserPresets.Controls.Add(Me.txtName2)
        Me.grpFocuserPresets.Controls.Add(Me.txtName1)
        Me.grpFocuserPresets.Controls.Add(Me.txtName0)
        Me.grpFocuserPresets.Controls.Add(Me.Label13)
        Me.grpFocuserPresets.Controls.Add(Me.Label12)
        Me.grpFocuserPresets.Controls.Add(Me.Label11)
        Me.grpFocuserPresets.Controls.Add(Me.Label10)
        Me.grpFocuserPresets.Controls.Add(Me.Label9)
        Me.grpFocuserPresets.Controls.Add(Me.Label8)
        Me.grpFocuserPresets.Controls.Add(Me.Label7)
        Me.grpFocuserPresets.Controls.Add(Me.Label6)
        Me.grpFocuserPresets.Controls.Add(Me.Label5)
        Me.grpFocuserPresets.Controls.Add(Me.Label4)
        Me.grpFocuserPresets.Controls.Add(Me.Label3)
        Me.grpFocuserPresets.Enabled = False
        Me.grpFocuserPresets.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpFocuserPresets.Location = New System.Drawing.Point(202, 12)
        Me.grpFocuserPresets.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.grpFocuserPresets.Name = "grpFocuserPresets"
        Me.grpFocuserPresets.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.grpFocuserPresets.Size = New System.Drawing.Size(422, 475)
        Me.grpFocuserPresets.TabIndex = 15
        Me.grpFocuserPresets.TabStop = False
        Me.grpFocuserPresets.Text = "Focuser Position Presets"
        '
        'btnGetPresets
        '
        Me.btnGetPresets.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnGetPresets.Location = New System.Drawing.Point(268, 446)
        Me.btnGetPresets.Name = "btnGetPresets"
        Me.btnGetPresets.Size = New System.Drawing.Size(131, 23)
        Me.btnGetPresets.TabIndex = 106
        Me.btnGetPresets.Text = "Load Presets From File"
        Me.btnGetPresets.UseVisualStyleBackColor = True
        '
        'lblBacklash
        '
        Me.lblBacklash.AutoSize = True
        Me.lblBacklash.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblBacklash.Location = New System.Drawing.Point(268, 413)
        Me.lblBacklash.Name = "lblBacklash"
        Me.lblBacklash.Size = New System.Drawing.Size(110, 25)
        Me.lblBacklash.TabIndex = 85
        Me.lblBacklash.Text = "BACKLASH"
        Me.lblBacklash.Visible = False
        '
        'txtLastMove
        '
        Me.txtLastMove.BackColor = System.Drawing.SystemColors.Info
        Me.txtLastMove.Enabled = False
        Me.txtLastMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.txtLastMove.Location = New System.Drawing.Point(139, 317)
        Me.txtLastMove.Name = "txtLastMove"
        Me.txtLastMove.Size = New System.Drawing.Size(75, 35)
        Me.txtLastMove.TabIndex = 105
        Me.txtLastMove.Text = "---"
        Me.txtLastMove.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(142, 303)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(66, 13)
        Me.Label14.TabIndex = 104
        Me.Label14.Text = "Last Move"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label20.Location = New System.Drawing.Point(11, 417)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(98, 13)
        Me.Label20.TabIndex = 98
        Me.Label20.Text = "Steps for << >> "
        '
        'lblUpdating
        '
        Me.lblUpdating.AutoSize = True
        Me.lblUpdating.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblUpdating.Location = New System.Drawing.Point(268, 413)
        Me.lblUpdating.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUpdating.Name = "lblUpdating"
        Me.lblUpdating.Size = New System.Drawing.Size(140, 24)
        Me.lblUpdating.TabIndex = 78
        Me.lblUpdating.Text = "Updating Data"
        Me.lblUpdating.Visible = False
        '
        'cbxMoves
        '
        Me.cbxMoves.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.cbxMoves.FormattingEnabled = True
        Me.cbxMoves.ItemHeight = 13
        Me.cbxMoves.Location = New System.Drawing.Point(11, 439)
        Me.cbxMoves.Name = "cbxMoves"
        Me.cbxMoves.Size = New System.Drawing.Size(121, 21)
        Me.cbxMoves.TabIndex = 103
        '
        'lblRetrieve
        '
        Me.lblRetrieve.AutoSize = True
        Me.lblRetrieve.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblRetrieve.Location = New System.Drawing.Point(263, 413)
        Me.lblRetrieve.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblRetrieve.Name = "lblRetrieve"
        Me.lblRetrieve.Size = New System.Drawing.Size(151, 24)
        Me.lblRetrieve.TabIndex = 77
        Me.lblRetrieve.Text = "Retrieving Data"
        Me.lblRetrieve.Visible = False
        '
        'btnMoveFullyOut
        '
        Me.btnMoveFullyOut.Location = New System.Drawing.Point(349, 373)
        Me.btnMoveFullyOut.Name = "btnMoveFullyOut"
        Me.btnMoveFullyOut.Size = New System.Drawing.Size(50, 30)
        Me.btnMoveFullyOut.TabIndex = 49
        Me.btnMoveFullyOut.Text = ">>|"
        Me.btnMoveFullyOut.UseVisualStyleBackColor = True
        '
        'btnMoveOut
        '
        Me.btnMoveOut.Location = New System.Drawing.Point(293, 373)
        Me.btnMoveOut.Name = "btnMoveOut"
        Me.btnMoveOut.Size = New System.Drawing.Size(50, 30)
        Me.btnMoveOut.TabIndex = 48
        Me.btnMoveOut.Text = ">>"
        Me.btnMoveOut.UseVisualStyleBackColor = True
        '
        'btnPulseOut
        '
        Me.btnPulseOut.Location = New System.Drawing.Point(237, 373)
        Me.btnPulseOut.Name = "btnPulseOut"
        Me.btnPulseOut.Size = New System.Drawing.Size(50, 30)
        Me.btnPulseOut.TabIndex = 47
        Me.btnPulseOut.Text = ">"
        Me.btnPulseOut.UseVisualStyleBackColor = True
        '
        'lblMoving
        '
        Me.lblMoving.AutoSize = True
        Me.lblMoving.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblMoving.Location = New System.Drawing.Point(268, 413)
        Me.lblMoving.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMoving.Name = "lblMoving"
        Me.lblMoving.Size = New System.Drawing.Size(92, 24)
        Me.lblMoving.TabIndex = 76
        Me.lblMoving.Text = "MOVING"
        Me.lblMoving.Visible = False
        '
        'btnPulseIn
        '
        Me.btnPulseIn.Location = New System.Drawing.Point(123, 373)
        Me.btnPulseIn.Name = "btnPulseIn"
        Me.btnPulseIn.Size = New System.Drawing.Size(50, 30)
        Me.btnPulseIn.TabIndex = 45
        Me.btnPulseIn.Text = "<"
        Me.btnPulseIn.UseVisualStyleBackColor = True
        '
        'btnMoveIn
        '
        Me.btnMoveIn.Location = New System.Drawing.Point(67, 373)
        Me.btnMoveIn.Name = "btnMoveIn"
        Me.btnMoveIn.Size = New System.Drawing.Size(50, 30)
        Me.btnMoveIn.TabIndex = 44
        Me.btnMoveIn.Text = "<<"
        Me.btnMoveIn.UseVisualStyleBackColor = True
        '
        'btnMoveFullyIn
        '
        Me.btnMoveFullyIn.Location = New System.Drawing.Point(11, 373)
        Me.btnMoveFullyIn.Name = "btnMoveFullyIn"
        Me.btnMoveFullyIn.Size = New System.Drawing.Size(50, 30)
        Me.btnMoveFullyIn.TabIndex = 43
        Me.btnMoveFullyIn.Text = "|<<"
        Me.btnMoveFullyIn.UseVisualStyleBackColor = True
        '
        'lblCurrPos
        '
        Me.lblCurrPos.AutoSize = True
        Me.lblCurrPos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblCurrPos.Location = New System.Drawing.Point(24, 303)
        Me.lblCurrPos.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCurrPos.Name = "lblCurrPos"
        Me.lblCurrPos.Size = New System.Drawing.Size(97, 13)
        Me.lblCurrPos.TabIndex = 27
        Me.lblCurrPos.Text = "Current Position"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label26.Location = New System.Drawing.Point(221, 329)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(67, 13)
        Me.Label26.TabIndex = 91
        Me.Label26.Text = "Move <<  >>"
        '
        'nudMove
        '
        Me.nudMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudMove.Location = New System.Drawing.Point(291, 325)
        Me.nudMove.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudMove.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudMove.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudMove.Name = "nudMove"
        Me.nudMove.Size = New System.Drawing.Size(79, 20)
        Me.nudMove.TabIndex = 42
        Me.nudMove.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'nudPreset9
        '
        Me.nudPreset9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset9.Location = New System.Drawing.Point(291, 272)
        Me.nudPreset9.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset9.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset9.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset9.Name = "nudPreset9"
        Me.nudPreset9.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset9.TabIndex = 38
        Me.nudPreset9.Value = New Decimal(New Integer() {1000000, 0, 0, 0})
        '
        'nudPreset8
        '
        Me.nudPreset8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset8.Location = New System.Drawing.Point(291, 249)
        Me.nudPreset8.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset8.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset8.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset8.Name = "nudPreset8"
        Me.nudPreset8.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset8.TabIndex = 36
        Me.nudPreset8.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'btnGoto
        '
        Me.btnGoto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnGoto.Location = New System.Drawing.Point(180, 373)
        Me.btnGoto.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btnGoto.Name = "btnGoto"
        Me.btnGoto.Size = New System.Drawing.Size(50, 30)
        Me.btnGoto.TabIndex = 46
        Me.btnGoto.Text = "GO"
        Me.btnGoto.UseVisualStyleBackColor = True
        '
        'nudPreset7
        '
        Me.nudPreset7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset7.Location = New System.Drawing.Point(291, 226)
        Me.nudPreset7.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset7.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset7.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset7.Name = "nudPreset7"
        Me.nudPreset7.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset7.TabIndex = 33
        Me.nudPreset7.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudPreset6
        '
        Me.nudPreset6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset6.Location = New System.Drawing.Point(292, 203)
        Me.nudPreset6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset6.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset6.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset6.Name = "nudPreset6"
        Me.nudPreset6.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset6.TabIndex = 30
        Me.nudPreset6.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudPreset5
        '
        Me.nudPreset5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset5.Location = New System.Drawing.Point(291, 180)
        Me.nudPreset5.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset5.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset5.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset5.Name = "nudPreset5"
        Me.nudPreset5.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset5.TabIndex = 27
        Me.nudPreset5.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudPreset4
        '
        Me.nudPreset4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset4.Location = New System.Drawing.Point(291, 157)
        Me.nudPreset4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset4.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset4.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset4.Name = "nudPreset4"
        Me.nudPreset4.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset4.TabIndex = 24
        Me.nudPreset4.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudPreset3
        '
        Me.nudPreset3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset3.Location = New System.Drawing.Point(291, 134)
        Me.nudPreset3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset3.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset3.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset3.Name = "nudPreset3"
        Me.nudPreset3.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset3.TabIndex = 21
        Me.nudPreset3.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudPreset2
        '
        Me.nudPreset2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset2.Location = New System.Drawing.Point(291, 111)
        Me.nudPreset2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset2.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset2.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset2.Name = "nudPreset2"
        Me.nudPreset2.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset2.TabIndex = 18
        Me.nudPreset2.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudPreset1
        '
        Me.nudPreset1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset1.Location = New System.Drawing.Point(291, 88)
        Me.nudPreset1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset1.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset1.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset1.Name = "nudPreset1"
        Me.nudPreset1.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset1.TabIndex = 15
        Me.nudPreset1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudPreset0
        '
        Me.nudPreset0.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudPreset0.Location = New System.Drawing.Point(291, 65)
        Me.nudPreset0.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudPreset0.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudPreset0.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPreset0.Name = "nudPreset0"
        Me.nudPreset0.Size = New System.Drawing.Size(79, 20)
        Me.nudPreset0.TabIndex = 12
        Me.nudPreset0.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudCurrPos
        '
        Me.nudCurrPos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudCurrPos.Location = New System.Drawing.Point(291, 42)
        Me.nudCurrPos.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudCurrPos.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudCurrPos.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudCurrPos.Name = "nudCurrPos"
        Me.nudCurrPos.Size = New System.Drawing.Size(79, 20)
        Me.nudCurrPos.TabIndex = 11
        Me.nudCurrPos.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudTarget
        '
        Me.nudTarget.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudTarget.Location = New System.Drawing.Point(291, 302)
        Me.nudTarget.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudTarget.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.nudTarget.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudTarget.Name = "nudTarget"
        Me.nudTarget.Size = New System.Drawing.Size(79, 20)
        Me.nudTarget.TabIndex = 40
        Me.nudTarget.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'radTarget
        '
        Me.radTarget.AutoSize = True
        Me.radTarget.Location = New System.Drawing.Point(388, 308)
        Me.radTarget.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radTarget.Name = "radTarget"
        Me.radTarget.Size = New System.Drawing.Size(14, 13)
        Me.radTarget.TabIndex = 41
        Me.radTarget.TabStop = True
        Me.radTarget.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label21.Location = New System.Drawing.Point(219, 307)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(38, 13)
        Me.Label21.TabIndex = 75
        Me.Label21.Text = "Target"
        '
        'txtCurrPos
        '
        Me.txtCurrPos.BackColor = System.Drawing.SystemColors.Info
        Me.txtCurrPos.Enabled = False
        Me.txtCurrPos.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.txtCurrPos.Location = New System.Drawing.Point(9, 317)
        Me.txtCurrPos.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtCurrPos.Name = "txtCurrPos"
        Me.txtCurrPos.Size = New System.Drawing.Size(123, 35)
        Me.txtCurrPos.TabIndex = 72
        Me.txtCurrPos.Text = "------"
        Me.txtCurrPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnStop
        '
        Me.btnStop.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnStop.Location = New System.Drawing.Point(154, 409)
        Me.btnStop.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(106, 60)
        Me.btnStop.TabIndex = 50
        Me.btnStop.Text = "STOP"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(368, 22)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(43, 13)
        Me.Label17.TabIndex = 64
        Me.Label17.Text = "Select"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(292, 22)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(52, 13)
        Me.Label16.TabIndex = 63
        Me.Label16.Text = "Position"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(107, 22)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(39, 13)
        Me.Label15.TabIndex = 62
        Me.Label15.Text = "Name"
        '
        'radPreset9
        '
        Me.radPreset9.AutoSize = True
        Me.radPreset9.Location = New System.Drawing.Point(388, 276)
        Me.radPreset9.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset9.Name = "radPreset9"
        Me.radPreset9.Size = New System.Drawing.Size(14, 13)
        Me.radPreset9.TabIndex = 39
        Me.radPreset9.TabStop = True
        Me.radPreset9.UseVisualStyleBackColor = True
        '
        'radPreset8
        '
        Me.radPreset8.AutoSize = True
        Me.radPreset8.Location = New System.Drawing.Point(388, 253)
        Me.radPreset8.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset8.Name = "radPreset8"
        Me.radPreset8.Size = New System.Drawing.Size(14, 13)
        Me.radPreset8.TabIndex = 37
        Me.radPreset8.TabStop = True
        Me.radPreset8.UseVisualStyleBackColor = True
        '
        'radPreset7
        '
        Me.radPreset7.AutoSize = True
        Me.radPreset7.Location = New System.Drawing.Point(388, 230)
        Me.radPreset7.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset7.Name = "radPreset7"
        Me.radPreset7.Size = New System.Drawing.Size(14, 13)
        Me.radPreset7.TabIndex = 34
        Me.radPreset7.TabStop = True
        Me.radPreset7.UseVisualStyleBackColor = True
        '
        'radPreset6
        '
        Me.radPreset6.AutoSize = True
        Me.radPreset6.Location = New System.Drawing.Point(388, 207)
        Me.radPreset6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset6.Name = "radPreset6"
        Me.radPreset6.Size = New System.Drawing.Size(14, 13)
        Me.radPreset6.TabIndex = 31
        Me.radPreset6.TabStop = True
        Me.radPreset6.UseVisualStyleBackColor = True
        '
        'radPreset5
        '
        Me.radPreset5.AutoSize = True
        Me.radPreset5.Location = New System.Drawing.Point(388, 183)
        Me.radPreset5.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset5.Name = "radPreset5"
        Me.radPreset5.Size = New System.Drawing.Size(14, 13)
        Me.radPreset5.TabIndex = 28
        Me.radPreset5.TabStop = True
        Me.radPreset5.UseVisualStyleBackColor = True
        '
        'radPreset4
        '
        Me.radPreset4.AutoSize = True
        Me.radPreset4.Location = New System.Drawing.Point(388, 160)
        Me.radPreset4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset4.Name = "radPreset4"
        Me.radPreset4.Size = New System.Drawing.Size(14, 13)
        Me.radPreset4.TabIndex = 25
        Me.radPreset4.TabStop = True
        Me.radPreset4.UseVisualStyleBackColor = True
        '
        'radPreset3
        '
        Me.radPreset3.AutoSize = True
        Me.radPreset3.Location = New System.Drawing.Point(388, 137)
        Me.radPreset3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset3.Name = "radPreset3"
        Me.radPreset3.Size = New System.Drawing.Size(14, 13)
        Me.radPreset3.TabIndex = 22
        Me.radPreset3.TabStop = True
        Me.radPreset3.UseVisualStyleBackColor = True
        '
        'radPreset2
        '
        Me.radPreset2.AutoSize = True
        Me.radPreset2.Location = New System.Drawing.Point(388, 114)
        Me.radPreset2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset2.Name = "radPreset2"
        Me.radPreset2.Size = New System.Drawing.Size(14, 13)
        Me.radPreset2.TabIndex = 19
        Me.radPreset2.TabStop = True
        Me.radPreset2.UseVisualStyleBackColor = True
        '
        'radPreset1
        '
        Me.radPreset1.AutoSize = True
        Me.radPreset1.Location = New System.Drawing.Point(388, 91)
        Me.radPreset1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset1.Name = "radPreset1"
        Me.radPreset1.Size = New System.Drawing.Size(14, 13)
        Me.radPreset1.TabIndex = 16
        Me.radPreset1.TabStop = True
        Me.radPreset1.UseVisualStyleBackColor = True
        '
        'radPreset0
        '
        Me.radPreset0.AutoSize = True
        Me.radPreset0.Location = New System.Drawing.Point(388, 68)
        Me.radPreset0.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radPreset0.Name = "radPreset0"
        Me.radPreset0.Size = New System.Drawing.Size(14, 13)
        Me.radPreset0.TabIndex = 13
        Me.radPreset0.UseVisualStyleBackColor = True
        '
        'txtName9
        '
        Me.txtName9.BackColor = System.Drawing.SystemColors.Info
        Me.txtName9.Enabled = False
        Me.txtName9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName9.Location = New System.Drawing.Point(72, 273)
        Me.txtName9.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName9.Name = "txtName9"
        Me.txtName9.Size = New System.Drawing.Size(213, 20)
        Me.txtName9.TabIndex = 35
        Me.txtName9.Text = "Upper Limit"
        '
        'txtName8
        '
        Me.txtName8.BackColor = System.Drawing.SystemColors.Window
        Me.txtName8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName8.Location = New System.Drawing.Point(72, 250)
        Me.txtName8.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName8.Name = "txtName8"
        Me.txtName8.Size = New System.Drawing.Size(213, 20)
        Me.txtName8.TabIndex = 35
        Me.txtName8.Text = "Preset 8"
        '
        'txtName7
        '
        Me.txtName7.BackColor = System.Drawing.SystemColors.Window
        Me.txtName7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName7.Location = New System.Drawing.Point(72, 227)
        Me.txtName7.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName7.Name = "txtName7"
        Me.txtName7.Size = New System.Drawing.Size(213, 20)
        Me.txtName7.TabIndex = 32
        Me.txtName7.Text = "Preset 7"
        '
        'txtName6
        '
        Me.txtName6.BackColor = System.Drawing.SystemColors.Window
        Me.txtName6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName6.Location = New System.Drawing.Point(72, 204)
        Me.txtName6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName6.Name = "txtName6"
        Me.txtName6.Size = New System.Drawing.Size(213, 20)
        Me.txtName6.TabIndex = 29
        Me.txtName6.Text = "Preset 6"
        '
        'txtName5
        '
        Me.txtName5.BackColor = System.Drawing.SystemColors.Window
        Me.txtName5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName5.Location = New System.Drawing.Point(72, 181)
        Me.txtName5.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName5.Name = "txtName5"
        Me.txtName5.Size = New System.Drawing.Size(213, 20)
        Me.txtName5.TabIndex = 26
        Me.txtName5.Text = "Preset 5"
        '
        'txtName4
        '
        Me.txtName4.BackColor = System.Drawing.SystemColors.Window
        Me.txtName4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName4.Location = New System.Drawing.Point(72, 158)
        Me.txtName4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName4.Name = "txtName4"
        Me.txtName4.Size = New System.Drawing.Size(213, 20)
        Me.txtName4.TabIndex = 23
        Me.txtName4.Text = "Preset 4"
        '
        'txtName3
        '
        Me.txtName3.BackColor = System.Drawing.SystemColors.Window
        Me.txtName3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName3.Location = New System.Drawing.Point(72, 135)
        Me.txtName3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName3.Name = "txtName3"
        Me.txtName3.Size = New System.Drawing.Size(213, 20)
        Me.txtName3.TabIndex = 20
        Me.txtName3.Text = "Preset 3"
        '
        'txtName2
        '
        Me.txtName2.BackColor = System.Drawing.SystemColors.Window
        Me.txtName2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName2.Location = New System.Drawing.Point(72, 112)
        Me.txtName2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName2.Name = "txtName2"
        Me.txtName2.Size = New System.Drawing.Size(213, 20)
        Me.txtName2.TabIndex = 17
        Me.txtName2.Text = "Preset 2"
        '
        'txtName1
        '
        Me.txtName1.BackColor = System.Drawing.SystemColors.Window
        Me.txtName1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName1.Location = New System.Drawing.Point(72, 89)
        Me.txtName1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName1.Name = "txtName1"
        Me.txtName1.Size = New System.Drawing.Size(213, 20)
        Me.txtName1.TabIndex = 14
        Me.txtName1.Text = "Preset 1"
        '
        'txtName0
        '
        Me.txtName0.BackColor = System.Drawing.SystemColors.Info
        Me.txtName0.Enabled = False
        Me.txtName0.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtName0.Location = New System.Drawing.Point(72, 66)
        Me.txtName0.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtName0.Name = "txtName0"
        Me.txtName0.Size = New System.Drawing.Size(213, 20)
        Me.txtName0.TabIndex = 26
        Me.txtName0.Text = "Home"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(11, 279)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(46, 13)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "Preset 9"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(11, 256)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 13)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Preset 8"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(11, 233)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 13)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Preset 7"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(11, 210)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(46, 13)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "Preset 6"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(11, 187)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 13)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "Preset 5"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(11, 164)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Preset 4"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(11, 141)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Preset 3"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(11, 118)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Preset 2"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(11, 95)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Preset 1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(11, 72)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Preset 0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(11, 48)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Current Position"
        '
        'btnSyncPos
        '
        Me.btnSyncPos.Enabled = False
        Me.btnSyncPos.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnSyncPos.Location = New System.Drawing.Point(105, 87)
        Me.btnSyncPos.Name = "btnSyncPos"
        Me.btnSyncPos.Size = New System.Drawing.Size(80, 27)
        Me.btnSyncPos.TabIndex = 106
        Me.btnSyncPos.Text = "Pos'n > Select"
        Me.btnSyncPos.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Enabled = False
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnUpdate.Location = New System.Drawing.Point(16, 157)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(80, 27)
        Me.btnUpdate.TabIndex = 2
        Me.btnUpdate.Text = "Update"
        '
        'btnInitialise
        '
        Me.btnInitialise.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnInitialise.Location = New System.Drawing.Point(16, 87)
        Me.btnInitialise.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btnInitialise.Name = "btnInitialise"
        Me.btnInitialise.Size = New System.Drawing.Size(80, 27)
        Me.btnInitialise.TabIndex = 1
        Me.btnInitialise.Text = "Initialise"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(3, 3)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 34)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "FocusBuddy"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(13, 38)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(61, 15)
        Me.label2.TabIndex = 21
        Me.label2.Text = "COM port"
        '
        'Timer1
        '
        Me.Timer1.Interval = 975
        '
        'grpBacklash
        '
        Me.grpBacklash.Controls.Add(Me.radBothWays)
        Me.grpBacklash.Controls.Add(Me.Label24)
        Me.grpBacklash.Controls.Add(Me.nudBacklash)
        Me.grpBacklash.Controls.Add(Me.radInward)
        Me.grpBacklash.Controls.Add(Me.radOutward)
        Me.grpBacklash.Controls.Add(Me.radBacklashDisabled)
        Me.grpBacklash.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpBacklash.Location = New System.Drawing.Point(16, 245)
        Me.grpBacklash.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.grpBacklash.Name = "grpBacklash"
        Me.grpBacklash.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.grpBacklash.Size = New System.Drawing.Size(165, 180)
        Me.grpBacklash.TabIndex = 25
        Me.grpBacklash.TabStop = False
        Me.grpBacklash.Text = "Backlash Allowance"
        '
        'radBothWays
        '
        Me.radBothWays.AutoSize = True
        Me.radBothWays.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.radBothWays.Location = New System.Drawing.Point(11, 92)
        Me.radBothWays.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radBothWays.Name = "radBothWays"
        Me.radBothWays.Size = New System.Drawing.Size(97, 17)
        Me.radBothWays.TabIndex = 9
        Me.radBothWays.Text = "Both Directions"
        Me.radBothWays.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label24.Location = New System.Drawing.Point(11, 126)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(99, 13)
        Me.Label24.TabIndex = 5
        Me.Label24.Text = "Steps (milliseconds)"
        '
        'nudBacklash
        '
        Me.nudBacklash.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudBacklash.Location = New System.Drawing.Point(11, 147)
        Me.nudBacklash.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.nudBacklash.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudBacklash.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudBacklash.Name = "nudBacklash"
        Me.nudBacklash.Size = New System.Drawing.Size(77, 20)
        Me.nudBacklash.TabIndex = 10
        Me.nudBacklash.Value = New Decimal(New Integer() {1000, 0, 0, 0})
        '
        'radInward
        '
        Me.radInward.AutoSize = True
        Me.radInward.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.radInward.Location = New System.Drawing.Point(11, 69)
        Me.radInward.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radInward.Name = "radInward"
        Me.radInward.Size = New System.Drawing.Size(109, 17)
        Me.radInward.TabIndex = 8
        Me.radInward.Text = "On Inward Moves"
        Me.radInward.UseVisualStyleBackColor = True
        '
        'radOutward
        '
        Me.radOutward.AutoSize = True
        Me.radOutward.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.radOutward.Location = New System.Drawing.Point(11, 46)
        Me.radOutward.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radOutward.Name = "radOutward"
        Me.radOutward.Size = New System.Drawing.Size(117, 17)
        Me.radOutward.TabIndex = 7
        Me.radOutward.Text = "On Outward Moves"
        Me.radOutward.UseVisualStyleBackColor = True
        '
        'radBacklashDisabled
        '
        Me.radBacklashDisabled.AutoSize = True
        Me.radBacklashDisabled.Checked = True
        Me.radBacklashDisabled.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.radBacklashDisabled.Location = New System.Drawing.Point(11, 23)
        Me.radBacklashDisabled.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.radBacklashDisabled.Name = "radBacklashDisabled"
        Me.radBacklashDisabled.Size = New System.Drawing.Size(66, 17)
        Me.radBacklashDisabled.TabIndex = 6
        Me.radBacklashDisabled.TabStop = True
        Me.radBacklashDisabled.Text = "Disabled"
        Me.radBacklashDisabled.UseVisualStyleBackColor = True
        '
        'chkConnectOnStartUp
        '
        Me.chkConnectOnStartUp.AutoSize = True
        Me.chkConnectOnStartUp.Location = New System.Drawing.Point(16, 192)
        Me.chkConnectOnStartUp.Name = "chkConnectOnStartUp"
        Me.chkConnectOnStartUp.Size = New System.Drawing.Size(136, 19)
        Me.chkConnectOnStartUp.TabIndex = 5
        Me.chkConnectOnStartUp.Text = "Initialise on start-up"
        Me.chkConnectOnStartUp.UseVisualStyleBackColor = True
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStatus.Location = New System.Drawing.Point(202, 490)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(31, 12)
        Me.lblStatus.TabIndex = 80
        Me.lblStatus.Text = "Status"
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = True
        Me.lblVersion.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblVersion.Location = New System.Drawing.Point(16, 490)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(36, 12)
        Me.lblVersion.TabIndex = 84
        Me.lblVersion.Text = "Version"
        '
        'btnSync
        '
        Me.btnSync.Enabled = False
        Me.btnSync.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnSync.Location = New System.Drawing.Point(105, 53)
        Me.btnSync.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btnSync.Name = "btnSync"
        Me.btnSync.Size = New System.Drawing.Size(80, 27)
        Me.btnSync.TabIndex = 85
        Me.btnSync.Text = "Select > Pos'n"
        '
        'chkRevDir
        '
        Me.chkRevDir.AutoSize = True
        Me.chkRevDir.Location = New System.Drawing.Point(16, 217)
        Me.chkRevDir.Name = "chkRevDir"
        Me.chkRevDir.Size = New System.Drawing.Size(127, 19)
        Me.chkRevDir.TabIndex = 106
        Me.chkRevDir.Text = "Reverse Direction"
        Me.chkRevDir.UseVisualStyleBackColor = True
        '
        'btnReFormat
        '
        Me.btnReFormat.Enabled = False
        Me.btnReFormat.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnReFormat.Location = New System.Drawing.Point(105, 157)
        Me.btnReFormat.Name = "btnReFormat"
        Me.btnReFormat.Size = New System.Drawing.Size(80, 27)
        Me.btnReFormat.TabIndex = 107
        Me.btnReFormat.Text = "Re-Format"
        Me.btnReFormat.UseVisualStyleBackColor = True
        '
        'btnMiniFocuser
        '
        Me.btnMiniFocuser.Enabled = False
        Me.btnMiniFocuser.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnMiniFocuser.Location = New System.Drawing.Point(16, 123)
        Me.btnMiniFocuser.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.btnMiniFocuser.Name = "btnMiniFocuser"
        Me.btnMiniFocuser.Size = New System.Drawing.Size(80, 27)
        Me.btnMiniFocuser.TabIndex = 108
        Me.btnMiniFocuser.Text = "Compact"
        '
        'grpSwitches
        '
        Me.grpSwitches.Controls.Add(Me.btnPower)
        Me.grpSwitches.Controls.Add(Me.btnELPanel)
        Me.grpSwitches.Controls.Add(Me.btnStepper)
        Me.grpSwitches.Controls.Add(Me.Label23)
        Me.grpSwitches.Controls.Add(Me.Label25)
        Me.grpSwitches.Controls.Add(Me.Label27)
        Me.grpSwitches.Enabled = False
        Me.grpSwitches.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.grpSwitches.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpSwitches.Location = New System.Drawing.Point(735, 39)
        Me.grpSwitches.Name = "grpSwitches"
        Me.grpSwitches.Size = New System.Drawing.Size(165, 105)
        Me.grpSwitches.TabIndex = 112
        Me.grpSwitches.TabStop = False
        Me.grpSwitches.Text = "Switches"
        '
        'btnPower
        '
        Me.btnPower.BackColor = System.Drawing.SystemColors.Control
        Me.btnPower.Location = New System.Drawing.Point(119, 20)
        Me.btnPower.Name = "btnPower"
        Me.btnPower.Size = New System.Drawing.Size(37, 23)
        Me.btnPower.TabIndex = 117
        Me.btnPower.Text = "--"
        Me.btnPower.UseVisualStyleBackColor = False
        '
        'btnELPanel
        '
        Me.btnELPanel.BackColor = System.Drawing.SystemColors.Control
        Me.btnELPanel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnELPanel.Location = New System.Drawing.Point(119, 76)
        Me.btnELPanel.Name = "btnELPanel"
        Me.btnELPanel.Size = New System.Drawing.Size(37, 23)
        Me.btnELPanel.TabIndex = 116
        Me.btnELPanel.Text = "--"
        Me.btnELPanel.UseVisualStyleBackColor = False
        '
        'btnStepper
        '
        Me.btnStepper.BackColor = System.Drawing.SystemColors.Control
        Me.btnStepper.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnStepper.Location = New System.Drawing.Point(119, 48)
        Me.btnStepper.Name = "btnStepper"
        Me.btnStepper.Size = New System.Drawing.Size(37, 23)
        Me.btnStepper.TabIndex = 115
        Me.btnStepper.Text = "--"
        Me.btnStepper.UseVisualStyleBackColor = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label23.Location = New System.Drawing.Point(12, 24)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(70, 15)
        Me.Label23.TabIndex = 114
        Me.Label23.Text = "Main Power"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label25.Location = New System.Drawing.Point(12, 80)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(101, 15)
        Me.Label25.TabIndex = 113
        Me.Label25.Text = "EL Panel Flat Field"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label27.Location = New System.Drawing.Point(12, 52)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(89, 15)
        Me.Label27.TabIndex = 112
        Me.Label27.Text = "myFocuserPro2"
        '
        'grpHeaters
        '
        Me.grpHeaters.Controls.Add(Me.lblGuidescopeHeater)
        Me.grpHeaters.Controls.Add(Me.Label)
        Me.grpHeaters.Controls.Add(Me.tbrGuidescope)
        Me.grpHeaters.Controls.Add(Me.lblTelescopeHeater)
        Me.grpHeaters.Controls.Add(Me.tbrTelescope)
        Me.grpHeaters.Controls.Add(Me.Label18)
        Me.grpHeaters.Enabled = False
        Me.grpHeaters.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.grpHeaters.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpHeaters.Location = New System.Drawing.Point(636, 38)
        Me.grpHeaters.Name = "grpHeaters"
        Me.grpHeaters.Size = New System.Drawing.Size(87, 449)
        Me.grpHeaters.TabIndex = 113
        Me.grpHeaters.TabStop = False
        Me.grpHeaters.Text = "Heaters"
        '
        'lblGuidescopeHeater
        '
        Me.lblGuidescopeHeater.AutoSize = True
        Me.lblGuidescopeHeater.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblGuidescopeHeater.Location = New System.Drawing.Point(32, 420)
        Me.lblGuidescopeHeater.Name = "lblGuidescopeHeater"
        Me.lblGuidescopeHeater.Size = New System.Drawing.Size(17, 15)
        Me.lblGuidescopeHeater.TabIndex = 6
        Me.lblGuidescopeHeater.Text = "--"
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label.Location = New System.Drawing.Point(14, 251)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(72, 15)
        Me.Label.TabIndex = 4
        Me.Label.Text = "Guidescope"
        '
        'tbrGuidescope
        '
        Me.tbrGuidescope.BackColor = System.Drawing.SystemColors.Control
        Me.tbrGuidescope.LargeChange = 10
        Me.tbrGuidescope.Location = New System.Drawing.Point(21, 269)
        Me.tbrGuidescope.Maximum = 100
        Me.tbrGuidescope.Name = "tbrGuidescope"
        Me.tbrGuidescope.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrGuidescope.Size = New System.Drawing.Size(45, 150)
        Me.tbrGuidescope.SmallChange = 10
        Me.tbrGuidescope.TabIndex = 3
        Me.tbrGuidescope.TickFrequency = 10
        Me.tbrGuidescope.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'lblTelescopeHeater
        '
        Me.lblTelescopeHeater.AutoSize = True
        Me.lblTelescopeHeater.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblTelescopeHeater.Location = New System.Drawing.Point(32, 212)
        Me.lblTelescopeHeater.Name = "lblTelescopeHeater"
        Me.lblTelescopeHeater.Size = New System.Drawing.Size(17, 15)
        Me.lblTelescopeHeater.TabIndex = 5
        Me.lblTelescopeHeater.Text = "--"
        '
        'tbrTelescope
        '
        Me.tbrTelescope.BackColor = System.Drawing.SystemColors.Control
        Me.tbrTelescope.LargeChange = 10
        Me.tbrTelescope.Location = New System.Drawing.Point(21, 56)
        Me.tbrTelescope.Maximum = 100
        Me.tbrTelescope.Name = "tbrTelescope"
        Me.tbrTelescope.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.tbrTelescope.Size = New System.Drawing.Size(45, 150)
        Me.tbrTelescope.SmallChange = 10
        Me.tbrTelescope.TabIndex = 2
        Me.tbrTelescope.TickFrequency = 10
        Me.tbrTelescope.TickStyle = System.Windows.Forms.TickStyle.Both
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label18.Location = New System.Drawing.Point(14, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(62, 15)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Telescope"
        '
        'btnReset
        '
        Me.btnReset.Enabled = False
        Me.btnReset.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnReset.Location = New System.Drawing.Point(105, 123)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(80, 27)
        Me.btnReset.TabIndex = 114
        Me.btnReset.Text = "Reset Arduino"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'GitHubLogo
        '
        Me.GitHubLogo.Image = CType(resources.GetObject("GitHubLogo.Image"), System.Drawing.Image)
        Me.GitHubLogo.Location = New System.Drawing.Point(77, 428)
        Me.GitHubLogo.Name = "GitHubLogo"
        Me.GitHubLogo.Size = New System.Drawing.Size(66, 50)
        Me.GitHubLogo.TabIndex = 83
        Me.GitHubLogo.TabStop = False
        '
        'CMHASDLogo
        '
        Me.CMHASDLogo.Image = CType(resources.GetObject("CMHASDLogo.Image"), System.Drawing.Image)
        Me.CMHASDLogo.Location = New System.Drawing.Point(18, 428)
        Me.CMHASDLogo.Name = "CMHASDLogo"
        Me.CMHASDLogo.Size = New System.Drawing.Size(59, 50)
        Me.CMHASDLogo.TabIndex = 82
        Me.CMHASDLogo.TabStop = False
        '
        'Timer2
        '
        '
        'nudHours
        '
        Me.nudHours.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudHours.Location = New System.Drawing.Point(88, 20)
        Me.nudHours.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudHours.Name = "nudHours"
        Me.nudHours.Size = New System.Drawing.Size(58, 23)
        Me.nudHours.TabIndex = 116
        '
        'nudMins
        '
        Me.nudMins.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.nudMins.Location = New System.Drawing.Point(88, 44)
        Me.nudMins.Maximum = New Decimal(New Integer() {59, 0, 0, 0})
        Me.nudMins.Name = "nudMins"
        Me.nudMins.Size = New System.Drawing.Size(58, 23)
        Me.nudMins.TabIndex = 117
        '
        'grpTimer
        '
        Me.grpTimer.Controls.Add(Me.btnTimer)
        Me.grpTimer.Controls.Add(Me.lblMins)
        Me.grpTimer.Controls.Add(Me.lblHours)
        Me.grpTimer.Controls.Add(Me.nudMins)
        Me.grpTimer.Controls.Add(Me.nudHours)
        Me.grpTimer.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpTimer.Location = New System.Drawing.Point(735, 150)
        Me.grpTimer.Name = "grpTimer"
        Me.grpTimer.Size = New System.Drawing.Size(165, 115)
        Me.grpTimer.TabIndex = 118
        Me.grpTimer.TabStop = False
        Me.grpTimer.Text = "Power-Off Timer"
        '
        'btnTimer
        '
        Me.btnTimer.Location = New System.Drawing.Point(12, 75)
        Me.btnTimer.Name = "btnTimer"
        Me.btnTimer.Size = New System.Drawing.Size(141, 32)
        Me.btnTimer.TabIndex = 121
        Me.btnTimer.Text = "Start Timer"
        Me.btnTimer.UseVisualStyleBackColor = True
        '
        'lblMins
        '
        Me.lblMins.AutoSize = True
        Me.lblMins.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblMins.Location = New System.Drawing.Point(13, 46)
        Me.lblMins.Name = "lblMins"
        Me.lblMins.Size = New System.Drawing.Size(50, 15)
        Me.lblMins.TabIndex = 120
        Me.lblMins.Text = "Minutes"
        '
        'lblHours
        '
        Me.lblHours.AutoSize = True
        Me.lblHours.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblHours.Location = New System.Drawing.Point(12, 22)
        Me.lblHours.Name = "lblHours"
        Me.lblHours.Size = New System.Drawing.Size(39, 15)
        Me.lblHours.TabIndex = 119
        Me.lblHours.Text = "Hours"
        '
        'lblMillis
        '
        Me.lblMillis.AutoSize = True
        Me.lblMillis.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblMillis.Location = New System.Drawing.Point(977, 509)
        Me.lblMillis.Name = "lblMillis"
        Me.lblMillis.Size = New System.Drawing.Size(17, 12)
        Me.lblMillis.TabIndex = 0
        Me.lblMillis.Text = "    "
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label19.Location = New System.Drawing.Point(735, 266)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(136, 34)
        Me.Label19.TabIndex = 119
        Me.Label19.Text = "RoofBuddy"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label22.Location = New System.Drawing.Point(627, 1)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(206, 34)
        Me.Label22.TabIndex = 120
        Me.Label22.Text = "TopBox Controls"
        '
        'btnRBclose
        '
        Me.btnRBclose.Location = New System.Drawing.Point(88, 18)
        Me.btnRBclose.Name = "btnRBclose"
        Me.btnRBclose.Size = New System.Drawing.Size(70, 23)
        Me.btnRBclose.TabIndex = 121
        Me.btnRBclose.Text = "Close"
        Me.btnRBclose.UseVisualStyleBackColor = True
        '
        'btnRBopen
        '
        Me.btnRBopen.Location = New System.Drawing.Point(13, 18)
        Me.btnRBopen.Name = "btnRBopen"
        Me.btnRBopen.Size = New System.Drawing.Size(70, 23)
        Me.btnRBopen.TabIndex = 122
        Me.btnRBopen.Text = "Open"
        Me.btnRBopen.UseVisualStyleBackColor = True
        '
        'btnRBstop
        '
        Me.btnRBstop.Location = New System.Drawing.Point(12, 47)
        Me.btnRBstop.Name = "btnRBstop"
        Me.btnRBstop.Size = New System.Drawing.Size(70, 23)
        Me.btnRBstop.TabIndex = 123
        Me.btnRBstop.Text = "STOP"
        Me.btnRBstop.UseVisualStyleBackColor = True
        '
        'grpRBcontrols
        '
        Me.grpRBcontrols.Controls.Add(Me.Panel1)
        Me.grpRBcontrols.Controls.Add(Me.btnSettings)
        Me.grpRBcontrols.Controls.Add(Me.btnRBopen)
        Me.grpRBcontrols.Controls.Add(Me.btnRBstop)
        Me.grpRBcontrols.Controls.Add(Me.btnRBclose)
        Me.grpRBcontrols.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpRBcontrols.Location = New System.Drawing.Point(735, 300)
        Me.grpRBcontrols.Name = "grpRBcontrols"
        Me.grpRBcontrols.Size = New System.Drawing.Size(165, 187)
        Me.grpRBcontrols.TabIndex = 124
        Me.grpRBcontrols.TabStop = False
        Me.grpRBcontrols.Text = "Controls"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblLX200status)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.lblRBstatus)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.lblTemp)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.lblRain)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.lblBattery)
        Me.Panel1.Location = New System.Drawing.Point(13, 75)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(145, 106)
        Me.Panel1.TabIndex = 130
        '
        'lblLX200status
        '
        Me.lblLX200status.AutoSize = True
        Me.lblLX200status.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblLX200status.Location = New System.Drawing.Point(49, 82)
        Me.lblLX200status.Name = "lblLX200status"
        Me.lblLX200status.Size = New System.Drawing.Size(86, 15)
        Me.lblLX200status.TabIndex = 135
        Me.lblLX200status.Text = "No connection"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label32.Location = New System.Drawing.Point(2, 82)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(42, 15)
        Me.Label32.TabIndex = 134
        Me.Label32.Text = "LX200"
        '
        'lblRBstatus
        '
        Me.lblRBstatus.AutoSize = True
        Me.lblRBstatus.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblRBstatus.Location = New System.Drawing.Point(50, 43)
        Me.lblRBstatus.Name = "lblRBstatus"
        Me.lblRBstatus.Size = New System.Drawing.Size(43, 15)
        Me.lblRBstatus.TabIndex = 133
        Me.lblRBstatus.Text = "Closed"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label35.Location = New System.Drawing.Point(3, 43)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(42, 15)
        Me.Label35.TabIndex = 132
        Me.Label35.Text = "Status"
        '
        'lblTemp
        '
        Me.lblTemp.AutoSize = True
        Me.lblTemp.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblTemp.Location = New System.Drawing.Point(50, 62)
        Me.lblTemp.Name = "lblTemp"
        Me.lblTemp.Size = New System.Drawing.Size(20, 15)
        Me.lblTemp.TabIndex = 131
        Me.lblTemp.Text = "�C"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label28.Location = New System.Drawing.Point(3, 62)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(38, 15)
        Me.Label28.TabIndex = 130
        Me.Label28.Text = "Temp"
        '
        'lblRain
        '
        Me.lblRain.AutoSize = True
        Me.lblRain.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblRain.ForeColor = System.Drawing.Color.ForestGreen
        Me.lblRain.Location = New System.Drawing.Point(50, 24)
        Me.lblRain.Name = "lblRain"
        Me.lblRain.Size = New System.Drawing.Size(25, 15)
        Me.lblRain.TabIndex = 129
        Me.lblRain.Text = "Dry"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label29.Location = New System.Drawing.Point(3, 5)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(49, 15)
        Me.Label29.TabIndex = 126
        Me.Label29.Text = "Battery"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label31.Location = New System.Drawing.Point(3, 24)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(31, 15)
        Me.Label31.TabIndex = 128
        Me.Label31.Text = "Rain"
        '
        'lblBattery
        '
        Me.lblBattery.AutoSize = True
        Me.lblBattery.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblBattery.ForeColor = System.Drawing.Color.ForestGreen
        Me.lblBattery.Location = New System.Drawing.Point(50, 5)
        Me.lblBattery.Name = "lblBattery"
        Me.lblBattery.Size = New System.Drawing.Size(35, 15)
        Me.lblBattery.TabIndex = 127
        Me.lblBattery.Text = "12.8V"
        '
        'btnSettings
        '
        Me.btnSettings.Location = New System.Drawing.Point(88, 47)
        Me.btnSettings.Name = "btnSettings"
        Me.btnSettings.Size = New System.Drawing.Size(70, 23)
        Me.btnSettings.TabIndex = 125
        Me.btnSettings.Text = "Settings"
        Me.btnSettings.UseVisualStyleBackColor = True
        '
        'Timer3
        '
        Me.Timer3.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(910, 506)
        Me.Controls.Add(Me.grpRBcontrols)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.btnSyncPos)
        Me.Controls.Add(Me.lblMillis)
        Me.Controls.Add(Me.grpTimer)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.grpHeaters)
        Me.Controls.Add(Me.grpSwitches)
        Me.Controls.Add(Me.btnMiniFocuser)
        Me.Controls.Add(Me.btnReFormat)
        Me.Controls.Add(Me.chkRevDir)
        Me.Controls.Add(Me.btnSync)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.GitHubLogo)
        Me.Controls.Add(Me.CMHASDLogo)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.chkConnectOnStartUp)
        Me.Controls.Add(Me.grpBacklash)
        Me.Controls.Add(Me.btnInitialise)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grpFocuserPresets)
        Me.Controls.Add(Me.ComboBoxComPort)
        Me.Controls.Add(Me.btnUpdate)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ConsoleBuddy"
        Me.grpFocuserPresets.ResumeLayout(False)
        Me.grpFocuserPresets.PerformLayout()
        CType(Me.nudMove, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPreset0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudCurrPos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTarget, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpBacklash.ResumeLayout(False)
        Me.grpBacklash.PerformLayout()
        CType(Me.nudBacklash, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpSwitches.ResumeLayout(False)
        Me.grpSwitches.PerformLayout()
        Me.grpHeaters.ResumeLayout(False)
        Me.grpHeaters.PerformLayout()
        CType(Me.tbrGuidescope, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbrTelescope, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GitHubLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CMHASDLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudHours, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudMins, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpTimer.ResumeLayout(False)
        Me.grpTimer.PerformLayout()
        Me.grpRBcontrols.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBoxComPort As System.Windows.Forms.ComboBox
    Friend WithEvents grpFocuserPresets As GroupBox
    Friend WithEvents lblMoving As Label
    Friend WithEvents radTarget As RadioButton
    Friend WithEvents Label21 As Label
    Friend WithEvents txtCurrPos As TextBox
    Friend WithEvents btnStop As Button
    Friend WithEvents btnGoto As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents radPreset9 As RadioButton
    Friend WithEvents radPreset8 As RadioButton
    Friend WithEvents radPreset7 As RadioButton
    Friend WithEvents radPreset6 As RadioButton
    Friend WithEvents radPreset5 As RadioButton
    Friend WithEvents radPreset4 As RadioButton
    Friend WithEvents radPreset3 As RadioButton
    Friend WithEvents radPreset2 As RadioButton
    Friend WithEvents radPreset1 As RadioButton
    Friend WithEvents radPreset0 As RadioButton
    Friend WithEvents txtName9 As TextBox
    Friend WithEvents txtName8 As TextBox
    Friend WithEvents txtName7 As TextBox
    Friend WithEvents txtName6 As TextBox
    Friend WithEvents txtName5 As TextBox
    Friend WithEvents txtName4 As TextBox
    Friend WithEvents txtName3 As TextBox
    Friend WithEvents txtName2 As TextBox
    Friend WithEvents txtName1 As TextBox
    Friend WithEvents txtName0 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Private WithEvents label2 As Label
    Friend WithEvents btnInitialise As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents nudTarget As NumericUpDown
    Friend WithEvents grpBacklash As GroupBox
    Friend WithEvents Label24 As Label
    Friend WithEvents nudBacklash As NumericUpDown
    Friend WithEvents radInward As RadioButton
    Friend WithEvents radOutward As RadioButton
    Friend WithEvents radBacklashDisabled As RadioButton
    Friend WithEvents nudPreset9 As NumericUpDown
    Friend WithEvents nudPreset8 As NumericUpDown
    Friend WithEvents nudPreset7 As NumericUpDown
    Friend WithEvents nudPreset6 As NumericUpDown
    Friend WithEvents nudPreset5 As NumericUpDown
    Friend WithEvents nudPreset4 As NumericUpDown
    Friend WithEvents nudPreset3 As NumericUpDown
    Friend WithEvents nudPreset2 As NumericUpDown
    Friend WithEvents nudPreset1 As NumericUpDown
    Friend WithEvents nudPreset0 As NumericUpDown
    Friend WithEvents nudCurrPos As NumericUpDown
    Friend WithEvents Label26 As Label
    Friend WithEvents lblCurrPos As Label
    Friend WithEvents lblRetrieve As Label
    Friend WithEvents lblUpdating As Label
    Friend WithEvents chkConnectOnStartUp As CheckBox
    Friend WithEvents lblStatus As Label
    Friend WithEvents radBothWays As RadioButton
    Friend WithEvents cbxMoves As ComboBox
    Friend WithEvents btnMoveFullyOut As Button
    Friend WithEvents btnMoveOut As Button
    Friend WithEvents btnPulseOut As Button
    Friend WithEvents btnPulseIn As Button
    Friend WithEvents btnMoveIn As Button
    Friend WithEvents btnMoveFullyIn As Button
    Private WithEvents Label20 As Label
    Friend WithEvents txtLastMove As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents lblVersion As Label
    Friend WithEvents lblBacklash As Label
    Friend WithEvents btnSync As Button
    Friend WithEvents chkRevDir As CheckBox
    Friend WithEvents btnReFormat As Button
    Friend WithEvents btnMiniFocuser As Button
    Friend WithEvents nudMove As NumericUpDown
    Friend WithEvents grpSwitches As GroupBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents btnPower As Button
    Friend WithEvents btnELPanel As Button
    Friend WithEvents btnStepper As Button
    Friend WithEvents grpHeaters As GroupBox
    Friend WithEvents tbrGuidescope As TrackBar
    Friend WithEvents tbrTelescope As TrackBar
    Friend WithEvents Label18 As Label
    Friend WithEvents Label As Label
    Friend WithEvents lblGuidescopeHeater As Label
    Friend WithEvents lblTelescopeHeater As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents GitHubLogo As PictureBox
    Friend WithEvents CMHASDLogo As PictureBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents nudHours As NumericUpDown
    Friend WithEvents nudMins As NumericUpDown
    Friend WithEvents grpTimer As GroupBox
    Friend WithEvents lblMins As Label
    Friend WithEvents lblHours As Label
    Friend WithEvents btnTimer As Button
    Friend WithEvents lblMillis As Label
    Friend WithEvents btnSyncPos As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents btnRBclose As Button
    Friend WithEvents btnRBopen As Button
    Friend WithEvents btnRBstop As Button
    Friend WithEvents grpRBcontrols As GroupBox
    Friend WithEvents btnSettings As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblRain As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents lblBattery As Label
    Friend WithEvents lblRBstatus As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents lblTemp As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents lblLX200status As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Timer3 As Timer
    Friend WithEvents btnGetPresets As Button
    Friend WithEvents lblProg As Label
End Class
